using Classes;
namespace Interfaces
{
    public interface IGameCatalog
    {
        void AddGame(BoardGame game);
        void RemoveGame();
        void AddGames(BoardGame[] games);
        void RemoveGame(int index);
        void DisplayCatalog();
    }

    public interface IAnalyzer
    {
        double AverageMinPlayers(BoardGame[] games);
        double AverageMaxPlayers(BoardGame[] games);
        double MeanPlayerRange(BoardGame[] games);
        double MeanAgeRestriction(BoardGame[] games);
    }
}