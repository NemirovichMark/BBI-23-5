﻿using Interfaces;
namespace Classes
{
    public partial class GameCatalog : IAnalyzer
    {
        public double AverageMinPlayers(BoardGame[] games)
        {
            return games.Average(g => g.MinimumPlayers);
        }

        public double AverageMaxPlayers(BoardGame[] games)
        {
            return games.Average(g => g.MaximumPlayers);
        }

        public double MeanPlayerRange(BoardGame[] games)
        {
            return games.Average(g => g.MaximumPlayers - g.MinimumPlayers);
        }

        public double MeanAgeRestriction(BoardGame[] games)
        {
            return games.Average(g => g.AgeRestriction);
        }
    }
}