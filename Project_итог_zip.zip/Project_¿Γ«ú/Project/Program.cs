﻿using Classes;
using Serializers;

class Program
{
    public static void Main()
    {
        Random r = new Random();
        GameCatalog catalog = new GameCatalog();
        string[] titles = { "А", "Б", "В", "Г", "Д", "Е", "Ё", "Ж", "З", "И", "Й", "К", "Л", "М", "Н" };
        string[] desc = { "boring", "normal", "meh", "x_x", ")_)", "0_0", "...", "X", "B)" };
        string[] sett = { "Dark", "magic", "Tears", "Glass", "Ice", "Party", "Deads" };
        string[] card = { "R", "B", "W" };
        BoardGame[] games = new BoardGame[30];
        int k = 0;
        while (k < 30)
        {
            int rr = r.Next(1, 3);
            switch (rr)
            {
                case 1:
                    games[k] = new CardGame(titles[r.Next(0, titles.Length-1)], r.Next(0, 4), r.Next(4, 8), r.Next(0, 18), desc[r.Next(0, desc.Length - 1)], card[r.Next(0, card.Length - 1)], r.Next(10, 30));
                    break;
                case 2:
                    games[k] = new StrategyGame(titles[r.Next(0, titles.Length - 1)], r.Next(0, 4), r.Next(4, 8), r.Next(0, 18), desc[r.Next(0, desc.Length - 1)], r.Next(0, 1), r.Next(20, 120));
                    break;
                case 3:
                    games[k] = new PartyGame(titles[r.Next(0, titles.Length - 1)], r.Next(0, 4), r.Next(4, 8), r.Next(0, 18), desc[r.Next(0, desc.Length - 1)], r.Next(0, 1), sett[r.Next(0, sett.Length - 1)]);
                    break;
                default:
                    break;
                
            }
            k++;
        }
        for (int i = 0; i < 10; i++)
        {
            catalog.AddGame(games[i]);
        }
        MyJsonSerializer Json = new MyJsonSerializer();
        MyXmlSerializer Xml = new MyXmlSerializer();
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string folderName = "Packs";
        path = Path.Combine(path, folderName);
        if (!Directory.Exists(path))
        {
            Directory.CreateDirectory(path);
        }
        string fileName1 = Path.Combine(path, "raw_data.json");
        if (File.Exists(fileName1))
        {
            File.Delete(fileName1);
        }
        Json.Write<GameCatalog>(catalog, fileName1);
        string fileName2 = Path.Combine(path, "raw_data.xml");
        if (File.Exists(fileName2))
        {
            File.Delete(fileName2);
        }
        Xml.Write<GameCatalog>(catalog, fileName2);
        for (int i = 10; i < 20; i++)
        {
            catalog.AddGame(games[i]);
        }
        catalog.AddGame(new CardGame(titles[r.Next(0, titles.Length - 1)], r.Next(0, 4), r.Next(4, 8), r.Next(0, 18), desc[r.Next(0, desc.Length - 1)], card[r.Next(0, card.Length - 1)], r.Next(10, 30)));
        string fileName3 = Path.Combine(path, "data.json");
        if (File.Exists(fileName3))
        {
            File.Delete(fileName3);
        }
        Json.Write<GameCatalog>(catalog, fileName3);
        for (int i = 0;i < 5;i++) { catalog.RemoveGame(); }
        catalog.RemoveGame(6);
        string fileName4 = Path.Combine(path, "data.xml");
        if (File.Exists(fileName4))
        {
            File.Delete(fileName4);
        }
        Xml.Write<GameCatalog>(catalog, fileName4);
        catalog.DisplayCatalog();
        GameCatalog data1 = Json.Read<GameCatalog>(fileName1);
        Console.WriteLine("raw_data");
        data1.DisplayCatalog();
        GameCatalog data2 = Xml.Read<GameCatalog>(fileName2);
        data2.DisplayCatalog();
        Console.WriteLine("data");
        GameCatalog data3 = Json.Read<GameCatalog>(fileName3);
        Console.WriteLine("raw_data");
        data3.DisplayCatalog();
        GameCatalog data4 = Xml.Read<GameCatalog>(fileName4);
        data4.DisplayCatalog();
        MyBinSerializer Bin = new MyBinSerializer();
        for (int i = 20; i < 30; i++)
        {
            catalog.AddGame(games[i]);
        }
        string fileName5 = Path.Combine(path, "raw_data.bin");
        if (File.Exists(fileName5))
        {
            File.Delete(fileName5);
        }
        Bin.Write<GameCatalog>(catalog, fileName5);
        catalog.Sort();
        string fileName6 = Path.Combine(path, "sorted_data.bin");
        if (File.Exists(fileName6))
        {
            File.Delete(fileName6);
        }
        Bin.Write<GameCatalog>(catalog, fileName6);
        CardGame o = new CardGame();
        IEnumerable<BoardGame> cards = catalog.Filter(o.GetType());
        GameCatalog c = new GameCatalog();
        foreach (BoardGame board in cards) { c.AddGame(board); }
        Console.WriteLine($"Среднее мин кол-во игроков: {c.AverageMinPlayers}; макс: {c.AverageMaxPlayers}; разброс игроков: {c.MeanPlayerRange}; средний возраст: {c.MeanAgeRestriction}");
        for (int i = 0; i < catalog.Games.Count; i++) { catalog.RemoveGame(); }
        for (int i = 0; i < c.Games.Count; i++) { c.RemoveGame(); }
        GameCatalog data5 = Bin.Read<GameCatalog>(fileName5);
        Console.WriteLine("raw_data");
        data5.DisplayCatalog();
        GameCatalog data6 = Bin.Read<GameCatalog>(fileName6);
        Console.WriteLine("sorted_data");
        data6.DisplayCatalog();
        Console.ReadKey();
    }
}