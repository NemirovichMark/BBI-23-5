using Interfaces;
using ProtoBuf.WellKnownTypes;
using System.Xml.Serialization;
namespace Classes
{
    [ProtoBuf.ProtoContract()]
    [ProtoBuf.ProtoInclude(1, typeof(CardGame))]
    [ProtoBuf.ProtoInclude(2, typeof(StrategyGame))]
    [ProtoBuf.ProtoInclude(3, typeof(PartyGame))]
    [XmlInclude(typeof(CardGame))]
    [XmlInclude(typeof(StrategyGame))]
    [XmlInclude(typeof(PartyGame))]
    public class BoardGame
    {
        private string _title;
        private int _minimumPlayers;
        private int _maximumPlayers;
        private int _ageRestriction;
        private string _description;
        [ProtoBuf.ProtoMember(4)]
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }
        [ProtoBuf.ProtoMember(5)]
        public int MinimumPlayers
        {
            get { return _minimumPlayers; }
            set { _minimumPlayers = value; }
        }
        [ProtoBuf.ProtoMember(6)]
        public int MaximumPlayers
        {
            get { return _maximumPlayers; }
            set { _maximumPlayers = value; }
        }
        [ProtoBuf.ProtoMember(7)]
        public int AgeRestriction
        {
            get { return _ageRestriction; }
            set { _ageRestriction = value; }
        }
        [ProtoBuf.ProtoMember(8)]
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        public BoardGame() { }
        public BoardGame(string titl, int minimumPlayer, int maximumPlayer, int ageRestrictio, string descriptio)
        {
            Title = titl;
            MinimumPlayers = minimumPlayer;
            MaximumPlayers = maximumPlayer;
            AgeRestriction = ageRestrictio;
            Description = descriptio;
        }

        public override string ToString()
        {
            return $"{Title}: {Description}, Players: {MinimumPlayers}-{MaximumPlayers}, Age: {AgeRestriction}+";
        }
        public override int GetHashCode()
        {
            return Title.GetHashCode();
        }
    }
    [ProtoBuf.ProtoContract()]
    public class CardGame : BoardGame
    {
        private string _cardType;
        private int _deckSize;
        [ProtoBuf.ProtoMember(1)]
        public string CardType
        {
            get { return _cardType; }
            set { _cardType = value; }
        }
        [ProtoBuf.ProtoMember(2)]
        public int DeckSize
        {
            get { return _deckSize; }
            set { _deckSize = value; }
        }
        public CardGame(string titl, int minimumPlayer, int maximumPlayer, int ageRestrictio, string descriptio, string card, int deck) : base(titl, minimumPlayer, maximumPlayer, ageRestrictio, descriptio)
        {
            _cardType = card;
            _deckSize = deck;
        }
        public CardGame() { }
        public override string ToString()
        {
            return $"{base.ToString()}, Card Type: {CardType}, Deck Size: {DeckSize}";
        }
    }
    [ProtoBuf.ProtoContract()]
    public class StrategyGame : BoardGame
    {
        private bool _isCooperative;
        private int _duration;
        [ProtoBuf.ProtoMember(1)]
        public bool IsCooperative
        {
            get { return _isCooperative; }
            set { _isCooperative = value; }
        }
        [ProtoBuf.ProtoMember(2)]
        public int Duration
        {
            get { return _duration; }
            set { _duration = value; }
        }
        public StrategyGame(string titl, int minimumPlayer, int maximumPlayer, int ageRestrictio, string descriptio, int iss, int deck) : base(titl, minimumPlayer, maximumPlayer, ageRestrictio, descriptio)
        {
            if (iss == 0)
            {
                _isCooperative = false;
            }
            else { _isCooperative = true; }
            _duration = deck;
        }
        public StrategyGame() { }
        public override string ToString()
        {
            return $"{base.ToString()}, Cooperative: {IsCooperative}, Duration: {Duration} minutes";
        }
    }
    [ProtoBuf.ProtoContract()]
    public class PartyGame : BoardGame
    {
        private string _recommendedSetting;
        private bool _includesMusic;
        [ProtoBuf.ProtoMember(1)]
        public string RecommendedSetting
        {
            get { return _recommendedSetting; }
            set { _recommendedSetting = value; }
        }
        [ProtoBuf.ProtoMember(2)]
        public bool IncludesMusic
        {
            get { return _includesMusic; }
            set { _includesMusic = value; }
        }
        public PartyGame(string titl, int minimumPlayer, int maximumPlayer, int ageRestrictio, string descriptio, int iss, string deck) : base(titl, minimumPlayer, maximumPlayer, ageRestrictio, descriptio)
        {
            if (iss == 0)
            {
                _includesMusic = false;
            }
            else { _includesMusic = true; }
            _recommendedSetting = deck;
        }
        public PartyGame() { }
        public override string ToString()
        {
            return $"{base.ToString()}, Setting: {RecommendedSetting}, Includes Music: {IncludesMusic}";
        }
    }
    [ProtoBuf.ProtoContract()]
    [ProtoBuf.ProtoInclude(1, typeof(BoardGame))]
    public partial class GameCatalog : IGameCatalog
    {
        private List<BoardGame> games = new List<BoardGame>();
        [ProtoBuf.ProtoMember(2)]
        public List<BoardGame> Games { get { return games; } set { games = value; } }
        public GameCatalog() { }
        public void AddGame(BoardGame game)
        {
            games.Add(game);
        }

        public void RemoveGame()
        {
            if (games.Count > 0) games.RemoveAt(games.Count - 1);
        }

        public void AddGames(BoardGame[] games)
        {
            this.games.AddRange(games);
        }

        public void RemoveGame(int index)
        {
            if (index >= 0 && index < games.Count) games.RemoveAt(index);
        }

        public void DisplayCatalog()
        {
            foreach (var game in games)
            {
                Console.WriteLine(game);
            }
        }
    }

    



}
