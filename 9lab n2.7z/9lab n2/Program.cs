﻿using System;
using System.IO;
using ProtoBuf;
using System.Text.Json;
using System.Xml.Serialization;

[ProtoContract]
abstract class Human
{
    [ProtoMember(1)]
    public string FullName { get; set; }
    [ProtoMember(2)]
    public double Score { get; set; }

    protected Human() { } // Parameterless constructor needed for serialization.

    public Human(string fullName, double score)
    {
        FullName = fullName;
        Score = score;
    }
}

class Sportsman : Human
{
    private static int counter = 1;

    [ProtoMember(3)]
    public int Id { get; private set; }

    public Sportsman(string fullName, double score) : base(fullName, score)
    {
        Id = counter++;
    }

    public void GetInfo()
    {
        Console.WriteLine($"Sportsman {FullName} has id {Id} and score {Score}");
    }
}

class Serializer<T>
{
    public void Serialize(string filePath, T data)
    {
        using (var file = File.Create(filePath))
        {
            Serializer.Serialize(file, data);
        }
    }

    public T Deserialize(string filePath)
    {
        using (var file = File.OpenRead(filePath))
        {
            return Serializer.Deserialize<T>(file);
        }
    }
}

class JsonSerializer<T> : Serializer<T>
{
    public void Serialize(string filePath, T data)
    {
        string jsonData = JsonSerializer.Serialize(data);
        File.WriteAllText(filePath, jsonData);
    }

    public T Deserialize(string filePath)
    {
        string jsonData = File.ReadAllText(filePath);
        return JsonSerializer.Deserialize<T>(jsonData);
    }
}

class XmlSerializer<T> : Serializer<T>
{
    public void Serialize(string filePath, T data)
    {
        var serializer = new System.Xml.Serialization.XmlSerializer(typeof(T));
        using (var stream = new FileStream(filePath, FileMode.Create))
        {
            serializer.Serialize(stream, data);
        }
    }

    public T Deserialize(string filePath)
    {
        var serializer = new System.Xml.Serialization.XmlSerializer(typeof(T));
        using (var stream = new FileStream(filePath, FileMode.Open))
        {
            return (T)serializer.Deserialize(stream);
        }
    }
}

class BinarySerializer<T> : Serializer<T>
{
    public void Serialize(string filePath, T data)
    {
        using (var file = File.Create(filePath))
        {
            Serializer.Serialize(file, data);
        }
    }

    public T Deserialize(string filePath)
    {
        using (var file = File.OpenRead(filePath))
        {
            return Serializer.Deserialize<T>(file);
        }
    }
}

class Program
{
    static void Main()
    {
        Sportsman[] sportsman =
        {
            new Sportsman("Karyakin", 2.5),
            new Sportsman("Nepo", 3),
            new Sportsman("Karlsen", 4.5),
            new Sportsman("Botvink", 0.5),
            new Sportsman("Dubov", 4),
        };

        // Serialization
        var jsonSerializer = new JsonSerializer<Sportsman[]>();
        jsonSerializer.Serialize("SerializedData.json", sportsman);

        var xmlSerializer = new XmlSerializer<Sportsman[]>();
        xmlSerializer.Serialize("SerializedData.xml", sportsman);

        var binarySerializer = new BinarySerializer<Sportsman[]>();
        binarySerializer.Serialize("SerializedData.bin", sportsman);

        // Deserialization
        var deserializedJson = jsonSerializer.Deserialize("SerializedData.json");
        var deserializedXml = xmlSerializer.Deserialize("SerializedData.xml");
        var deserializedBinary = binarySerializer.Deserialize("SerializedData.bin");

        // Printing deserialized data
        Console.WriteLine("\nDeserialized Data:");
        foreach (var s in deserializedJson)
        {
            s.GetInfo();
        }
        foreach (var s in deserializedXml)
        {
            s.GetInfo();
        }
        foreach (var s in deserializedBinary)
        {
            s.GetInfo();
        }
    }
}