﻿using System;
using System;
using System.Xml.Linq;
using System.Numerics;
using Microsoft.VisualBasic;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using ProtoBuf;
using lab9_2.Serializers;
using System.Text.RegularExpressions;
using lab9_2.Serializers;

[ProtoBuf.ProtoContract()]
[ProtoBuf.ProtoInclude(1, typeof(LongJump))]
[ProtoBuf.ProtoInclude(2, typeof(HighJump))]

public class Athelete
{
    [ProtoBuf.ProtoMember(3)]
    public string _lastName;
    [ProtoBuf.ProtoMember(4)]
    public string LastName
    {
        get => _lastName;
        set => _lastName = value ?? string.Empty;
    }
    [ProtoBuf.ProtoMember(5)]
    public double[] _attempts;
    [ProtoBuf.ProtoMember(6)]
    public double[] Attempts
    {
        get => _attempts;
        set => _attempts = value;
    }
    public Athelete() { }
    public Athelete(string lastName, double[] attempts)
    {
        _lastName = lastName;
        _attempts = attempts;
    }
    public virtual void Print()
    {
        Console.WriteLine("Фамилия   {0}\t Результаты {1}\t",
                        _lastName, string.Join(", ", _attempts));
    }
    //public void SortAthletesByBestResult()
    //{
    //    int n = _athletes.Length;
    //    int gap = n / 2;
    //    while (gap > 0)
    //    {
    //        for (int i = gap; i < n; i++)
    //        {
    //            Athlete temp = _athletes[i];
    //            int j = i;
    //            while (j >= gap && _athletes[j - gap].BestResult < temp.BestResult)
    //            {
    //                _athletes[j] = _athletes[j - gap];
    //                j -= gap;
    //            }
    //            _athletes[j] = temp;
    //        }
    //        gap /= 2;
    //    }
    //}
}
[ProtoBuf.ProtoContract()]
public class LongJump : Athelete
{
    public LongJump() : base() { }
    public LongJump(string lastName, double[] attempts) : base(lastName, attempts)
    {
    }

    public override void Print()
    {
        //SortAthletesByBestResult();
        Console.WriteLine("Фамилия   {0}\t Результаты {1}\t",
                _lastName, string.Join(", ", _attempts));

    }
}
[ProtoBuf.ProtoContract()]
public class HighJump : Athelete
{
    public HighJump() : base() { }
    public HighJump(string lastName, double[] attempts) : base(lastName, attempts)
    {
    }

    public override void Print()
    {
        //SortAthletesByBestResult();
        Console.WriteLine("Фамилия   {0}\t Результаты {1}\t",
                 _lastName, string.Join(", ", _attempts));
    }
}
//public struct Athlete
//{
//    public string _lastName;
//    public double[] _attempts;
//    //public double _bestResult;
//    //public double BestResult => _bestResult;
//    public Athlete() { }

//    public Athlete(string lastName, double[] attempts)
//    {
//        _lastName = lastName;
//        _attempts = attempts;
//        //_bestResult = 0;
//        //_bestResult = FindBestResult(attempts);
//    }

//    //public double FindBestResult(double[] attempts)
//    //{
//    //    double best = attempts[0];
//    //    for (int i = 1; i < attempts.Length; i++)
//    //    {
//    //        if (attempts[i] > best)
//    //        {
//    //            best = attempts[i];
//    //        }
//    //    }
//    //    return best;
//    //}

//    public void Print()
//    {
//        Console.WriteLine($"{_lastName}");
//        Console.WriteLine(string.Join(", ", _attempts));
//    }
//}

public class Program
{
    static void Main()
    {
        LongJump[] longJumpAthletes = new LongJump[]
{
    new LongJump("Гогчан", new double[] { 238, 230, 240 }),
    new LongJump("Федунь", new double[] { 200, 210, 200 }),
    new LongJump("Сацик", new double[] { 190, 180, 185 }),
    new LongJump("Алейник", new double[] { 200, 198, 199 }),
    new LongJump("Кунгур", new double[] { 213, 213, 203 })
};
        HighJump[] highJumpAthletes = new HighJump[]
        {
    new HighJump("Гогчан", new double[] { 180, 185, 175 }),
    new HighJump("Федунь", new double[] { 190, 195, 192 }),
    new HighJump("Сацик", new double[] { 170, 175, 180 }),
    new HighJump("Алейник", new double[] { 185, 190, 195 }),
    new HighJump("Кунгур", new double[] { 175, 180, 185 })
        };
        Serial[] serializers = new Serial[3]
        {
            new JSONManager(),
            new BinManager(),
            new XMLManager()

        };
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        path = Path.Combine(path, "Task 2");
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string[] files = new string[3]
        {
            "longJumpJson.json",
            "longJumpBinary.bin",
            "longJumpXml.xml",

        };

        for (int i = 0; i < files.Length; i++)
        {
            serializers[i].Write(longJumpAthletes, Path.Combine(path, files[i]));
            longJumpAthletes = serializers[i].Read<LongJump[]>(Path.Combine(path, files[i]));
            foreach (LongJump atlet in longJumpAthletes)
            {
                atlet.Print();
            }

        }

        string[] filess = new string[3]
        {
            "highJumpJson.json",
            "highJumpBin.bin",
            "highJumpXml.xml",
        };



        for (int i = 0; i < filess.Length; i++)
        {
            serializers[i].Write(highJumpAthletes, Path.Combine(path, filess[i]));
            highJumpAthletes = serializers[i].Read<HighJump[]>(Path.Combine(path, filess[i]));
            foreach (HighJump atlet in highJumpAthletes)
            {
                atlet.Print();
            }
        }
    }
}
