﻿using P1;
using P2;
using P3;
using IIIProjects.Serializers;

//Объявление сериализатора
namespace IIIProjects
{
    class Program
    {
        public static UniversalSerializer serializer = new CustomJsonSerializer();

        public static void Main()
        {
            RunP1();
            RunP2();
            RunP3();
        }

        static void RunP1()
        {
            var countOfVotes = 35;

            var persons = new PersonOfTheYear[] {
            new PersonOfTheYear("Эмма Уотсон"),
            new PersonOfTheYear("Анастатися Ивлеева"),
            new PersonOfTheYear("Джон Смит"),
            new PersonOfTheYear("Александра Бортич"),
            new PersonOfTheYear("Билл Гейтс"),
            new PersonOfTheYear("Марк Цукерберг"),
            new PersonOfTheYear("Денис Петров"),
            new PersonOfTheYear("Павел Дуров"),
            new PersonOfTheYear("Алла Пугачёва"),
            new PersonOfTheYear("Волтер Вайт"),
            new PersonOfTheYear("Жанна Дарк"),
            new PersonOfTheYear("Стив Джопс")
        };

            CalculatePersonOfYear(countOfVotes, persons);

            var events = new EventOfTheYear[] {
            new EventOfTheYear("Событие 1", new DateTime(2001, 9, 11)),
            new EventOfTheYear("Событие 2", new DateTime(2007, 1, 1)),
            new EventOfTheYear("Событие 3", new DateTime(2008, 5, 5)),
            new EventOfTheYear("Событие 4", new DateTime(2020, 6, 6)),
            new EventOfTheYear("Событие 5", new DateTime(2022, 12, 7)),
            new EventOfTheYear("Событие 6", new DateTime(2002, 11, 8)),
            new EventOfTheYear("Событие 7", new DateTime(2003, 7, 6)),
            new EventOfTheYear("Событие 8", new DateTime(2005, 8, 9)),
            new EventOfTheYear("Событие 9", new DateTime(2016, 9, 2)),
            new EventOfTheYear("Событие 10", new DateTime(2019, 2, 5)),
            new EventOfTheYear("Событие 11", new DateTime(2017, 1, 2)),
            new EventOfTheYear("Событие 12", new DateTime(2012, 3, 4))
        };

            CalculateEventOfYear(countOfVotes, events);

            static void CalculatePersonOfYear(int countOfVotes, PersonOfTheYear[] persons)
            {
                CalculateObjectsOfTheYear(countOfVotes, persons);

                InsertionSort(persons);


                //Сериализация в json-файл
                serializer.Serialize(persons, "persons");

                //Парсинг из файла
                var parsedPersons = serializer.Deserialize<PersonOfTheYear[]>("persons", "");

                Console.WriteLine("============= Результаты (Люди года) =============");
                foreach (PersonOfTheYear person in parsedPersons)
                    Console.WriteLine(person.ConvertToReportString(countOfVotes));
                Console.WriteLine("==================================================");
            }

            static void CalculateEventOfYear(int countOfVotes, EventOfTheYear[] events)
            {
                CalculateObjectsOfTheYear(countOfVotes, events);

                InsertionSort(events);


                //Сериализация в json-файл
                serializer.Serialize(events, "events");

                //Парсинг из файла
                var parsedEvents = serializer.Deserialize<EventOfTheYear[]>("events", "");

                Console.WriteLine("============= Результаты (События года) =============");
                foreach (EventOfTheYear currentEvent in parsedEvents)
                    Console.WriteLine(currentEvent.ConvertToReportString(countOfVotes));
                Console.WriteLine("==================================================");
            }

            static void CalculateObjectsOfTheYear(int countOfVotes, ObjectOfVote[] objectsOfVotes)
            {
                for (int i = 0; i < countOfVotes; i++)
                {
                    var idOfObject = new Random().Next(0, objectsOfVotes.Length);

                    objectsOfVotes[idOfObject].Vote();
                }
            }


            static void InsertionSort(ObjectOfVote[] objectsOfVotes)
            {
                for (int i = 1; i < objectsOfVotes.Length; i++)
                {
                    ObjectOfVote k = objectsOfVotes[i];

                    int j = i - 1;

                    while (j >= 0 && objectsOfVotes[j].VotesCount < k.VotesCount)
                    {
                        objectsOfVotes[j + 1] = objectsOfVotes[j];
                        j--;
                    }
                    objectsOfVotes[j + 1] = k;
                }
            }
        }

        static void RunP2()
        {
            Diver[] divers = new Diver[]
            {
                new Diver("Иванов", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
                new Diver("Петров", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
                new Diver("Ткачук", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
                new Diver("Фролов", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
                new Diver("Семенов", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
                new Diver("Белых", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
                new Diver("Жучков", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
                new Diver("Громких", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
                new Diver("Игнатьев", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()})
            };

            //Демонстрация работы класса 3 метровых прыжков
            WaterJumps WaterJumps3m = new WaterJumps3m(divers);
            WaterJumps3m.Start(serializer);

            Diver[] divers2 = new Diver[]
            {
            new Diver("Иванов", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
            new Diver("Петров", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
            new Diver("Ткачук", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
            new Diver("Фролов", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
            new Diver("Семенов", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
            new Diver("Белых", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
            new Diver("Жучков", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
            new Diver("Громких", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()}),
            new Diver("Игнатьев", new Jump[]{new Jump(), new Jump(), new Jump(), new Jump()})
            };

            //Демонстрация работы класса 5 метровых прыжков
            WaterJumps WaterJumps5m = new WaterJumps5m(divers2);
            WaterJumps5m.Start(serializer);

        }

        static void RunP3()
        {
            var Groupes = new Group[]
        {
            new GroupA("Группа А", new Student[]
            {
                new Student("Виктория", "Ульянова"),
                new Student("Марк", "Богатырёв"),
                new Student("Олег", "Романов")
            }),
            new GroupB("Группа В", new Student[]
            {
                new Student("Мария", "Илонова"),
                new Student("Глеб", "Останкин"),
                new Student("Павел", "Васильев")
            }),
            new GroupC("Группа С", new Student[]
            {
                new Student("Анастасия", "Милова"),
                new Student("Марк", "Богатырёв"),
                new Student("Нина", "Светова")
            })
        };

            var Stream = new P3.Stream(Groupes);
            Stream.ShowReport(serializer);

        }
    }
}





