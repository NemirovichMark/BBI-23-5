﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IIIProjects.Serializers
{
    public class CustomBinSerializer : UniversalSerializer
    {
        public override T? Deserialize<T>(string fileName, string filePath = "") where T : default
        {
            var file = File.OpenRead(filePath + fileName + ".bin");

            T result = ProtoBuf.Serializer.Deserialize<T>(file);

            file.Dispose();

            return result;
        }

        public override void Serialize(object @object, string fileName, string filePath = "")
        {
            var file = File.Create(filePath + fileName + ".bin");

            ProtoBuf.Serializer.Serialize(file, @object);
            file.Dispose();
        }
    }
}
