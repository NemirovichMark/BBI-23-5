﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IIIProjects.Serializers
{
    public class CustomJsonSerializer : UniversalSerializer
    {
        public override T? Deserialize<T>(string fileName, string filePath = "") where T : default
        {
            string jsonFromFile = File.ReadAllText(filePath + fileName + ".json");
            return JsonConvert.DeserializeObject<T>(jsonFromFile);
        }

        public override void Serialize(object @object, string fileName, string filePath = "")
        {
            var stringJson = JsonConvert.SerializeObject(@object);
            File.WriteAllText(filePath + fileName + ".json", stringJson);
        }
    }
}
