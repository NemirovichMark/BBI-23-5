﻿using System;
using System.Text.Json;
using System.IO;
using System.Xml.Serialization;

using System;
using System.IO;
using System.Text.Json;
using System.Xml.Serialization;
[Serializable]
[XmlInclude(typeof(WomenTeam))]
[XmlInclude(typeof(MenTeam))]
public abstract class Team
{
    private int[] places;

    protected Team(int[] places)
    {
        this.places = places;
    }

    protected Team() { }

    public int[] Places
    {
        get { return places; }
        set { places = value; }
    }

    public abstract string Gender { get; }

    public int CalculatePoints()
    {
        int totalPoints = 0;
        foreach (int place in places)
        {
            switch (place)
            {
                case 1:
                    totalPoints += 5;
                    break;
                case 2:
                    totalPoints += 4;
                    break;
                case 3:
                    totalPoints += 3;
                    break;
                case 4:
                    totalPoints += 2;
                    break;
                case 5:
                    totalPoints += 1;
                    break;
                default:
                    break;
            }
        }
        return totalPoints;
    }
}
[Serializable]
public class WomenTeam : Team
{
    public WomenTeam() : base() { }
    public WomenTeam(int[] places) : base(places) { }

    public override string Gender => "Женская команда";
}
[Serializable]
public class MenTeam : Team
{
    public MenTeam() : base() { }
    public MenTeam(int[] places) : base(places) { }

    public override string Gender => "Мужская команда";
}


[XmlRoot("Teams")]
public class TeamWrapper
{
    [XmlElement("WomenTeam", typeof(WomenTeam))]
    [XmlElement("MenTeam", typeof(MenTeam))]
    public Team[] Teams { get; set; }

    public TeamWrapper() { }

    public TeamWrapper(Team[] teams)
    {
        Teams = teams;
    }
}


class Program
{
       static void Main()
    {
        Team[] womenteam = new WomenTeam[]
        {
            new WomenTeam(new int[] {27, 37, 36, 26, 28, 29}),
            new WomenTeam(new int[] {5, 8, 9, 10, 17, 12}),
            new WomenTeam(new int[] {13, 15, 1, 16, 11, 18})
        };
        Team[] menteam = new MenTeam[]
        {
            new MenTeam(new int[] {7, 2, 3, 14, 6, 4}),
            new MenTeam(new int[] {19, 23, 25, 20, 30, 35}),
            new MenTeam(new int[] {21, 24, 33, 34, 31, 22})
        };

        string basePath = @"C:\Users\novik\OneDrive\Рабочий стол\ser";
        string womenTeamsJsonFile = Path.Combine(basePath, "womenteam.json");
        string menTeamsJsonFile = Path.Combine(basePath, "menteam.json");
        string womenTeamsXmlFile = Path.Combine(basePath, "womenteam.xml");
        string menTeamsXmlFile = Path.Combine(basePath, "menteam.xml");
        string womenTeamsBinFile = Path.Combine(basePath, "womenteam.bin");
        string menTeamsBinFile = Path.Combine(basePath, "menteam.bin");

        MySerialize.SerializeToJsonFile(womenteam, womenTeamsJsonFile);
        MySerialize.SerializeToJsonFile(menteam, menTeamsJsonFile);

        MySerialize.SerializeToXmlFile(new TeamWrapper(womenteam), womenTeamsXmlFile);
        MySerialize.SerializeToXmlFile(new TeamWrapper(menteam), menTeamsXmlFile);

        MySerialize.SerializeToBinaryFile(womenteam, womenTeamsBinFile);
        MySerialize.SerializeToBinaryFile(menteam, menTeamsBinFile);

        Team[] deserializedWomenTeamFromJson = MySerialize.DeserializeFromJsonFile<WomenTeam[]>(womenTeamsJsonFile);
        Team[] deserializedMenTeamFromJson = MySerialize.DeserializeFromJsonFile<MenTeam[]>(menTeamsJsonFile);

        TeamWrapper deserializedWomenTeamFromXml = MySerialize.DeserializeFromXmlFile<TeamWrapper>(womenTeamsXmlFile);
        TeamWrapper deserializedMenTeamFromXml = MySerialize.DeserializeFromXmlFile<TeamWrapper>(menTeamsXmlFile);

        Team[] deserializedWomenTeamFromBin = MySerialize.DeserializeFromBinaryFile<WomenTeam[]>(womenTeamsBinFile);
        Team[] deserializedMenTeamFromBin = MySerialize.DeserializeFromBinaryFile<MenTeam[]>(menTeamsBinFile);

        Console.WriteLine("Результаты из JSON файлов:");
        CalculateAndPrintResults(deserializedWomenTeamFromJson, deserializedMenTeamFromJson);

        Console.WriteLine("\nРезультаты из XML файлов:");
        CalculateAndPrintResults(deserializedWomenTeamFromXml.Teams, deserializedMenTeamFromXml.Teams);

        Console.WriteLine("\nРезультаты из бинарных файлов:");
        CalculateAndPrintResults(deserializedWomenTeamFromBin, deserializedMenTeamFromBin);
    }
    static void CalculateAndPrintResults(Team[] womenTeams, Team[] menTeams)
    {
        int maxpoints = 0;
        Team winner = null;

        foreach (var team in womenTeams)
        {
            int points = team.CalculatePoints();
            Console.WriteLine($"{team.Gender} набрала {points} баллов");
            if (points > maxpoints)
            {
                maxpoints = points;
                winner = team;
            }
        }

        foreach (var team in menTeams)
        {
            int points = team.CalculatePoints();
            Console.WriteLine($"{team.Gender} набрала {points} баллов");
            if (points > maxpoints)
            {
                maxpoints = points;
                winner = team;
            }
        }

        if (winner != null)
        {
            Console.WriteLine($"Победитель {winner.Gender} набравшая {maxpoints} баллов");
        }
    }
}
