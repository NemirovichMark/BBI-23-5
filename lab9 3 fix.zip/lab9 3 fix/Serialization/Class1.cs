﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.Json;
using System.Xml.Serialization;
#pragma warning disable SYSLIB0011
public static class MySerialize
{
    public static void SerializeToJsonFile<T>(T obj, string filePath)
    {
        var options = new JsonSerializerOptions
        {
            WriteIndented = true
        };
        string jsonString = JsonSerializer.Serialize(obj, options);
        File.WriteAllText(filePath, jsonString);
    }

    public static T DeserializeFromJsonFile<T>(string filePath)
    {
        string jsonString = File.ReadAllText(filePath);
        return JsonSerializer.Deserialize<T>(jsonString);
    }

    public static void SerializeToXmlFile<T>(T obj, string filePath)
    {
        XmlSerializer serializer = new XmlSerializer(typeof(T));
        using (StreamWriter writer = new StreamWriter(filePath))
        {
            serializer.Serialize(writer, obj);
        }
    }

    public static T DeserializeFromXmlFile<T>(string filePath)
    {
        XmlSerializer serializer = new XmlSerializer(typeof(T));
        using (StreamReader reader = new StreamReader(filePath))
        {
            return (T)serializer.Deserialize(reader);
        }
    }
    
    public static void SerializeToBinaryFile<T>(T obj, string filePath)
    {
        IFormatter formatter = new BinaryFormatter();
        using (Stream stream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None))
        {
            formatter.Serialize(stream, obj);
        }
    }

    public static T DeserializeFromBinaryFile<T>(string filePath)
    {
        IFormatter formatter = new BinaryFormatter();
        using (Stream stream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
        {
            return (T)formatter.Deserialize(stream);
        }
    }
}
