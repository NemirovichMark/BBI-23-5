﻿interface ISettleable
{
    void Add(ScheduleItem item);
    void Remove();
    void ChangeStart(DateTime newStartTime);
    void ChangeEnd(DateTime newEndTime);
}
public partial class Schedule : ISettleable
{
    protected List<ScheduleItem> items = new List<ScheduleItem>();
    public List<ScheduleItem> Items
    {
        get { return items; }
        set { items = value; }
    }
    public void Add(ScheduleItem item)
    {
        //if (items.Count == 0 || (items.Last().EndTime == item.StartTime /* && items.Last().GetType != item.GetType*/)) items.Add(item);
        //else Console.WriteLine("Addition failed");
        items.Add(item);
    }
    public void Remove()
    {
        if (items.Count > 0)
        {
            items.RemoveAt(items.Count - 1);
        }
    }
    public void ChangeStart(DateTime newStartTime)
    {
        if (items.Count > 0)
        {
            items.Last().StartTime = newStartTime;
        }
    }
    public void ChangeEnd(DateTime newEndTime)
    {
        if (items.Count > 0)
        {
            items.Last().EndTime = newEndTime;
        }
    }
    public void PrintInfo()
    {
        foreach (var item in items)
        {
            Console.WriteLine(item);
        }
    }
}

