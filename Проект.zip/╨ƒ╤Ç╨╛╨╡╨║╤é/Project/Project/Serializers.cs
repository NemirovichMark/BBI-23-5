﻿using System.Text.Json;
public abstract class MySerializer
{
    public abstract T Read<T>(string path);
    public abstract void Write<T>(Schedule[] obj, string path);
}
public class MyJsonSerializer : MySerializer
{
    JsonSerializerOptions options = new JsonSerializerOptions
    {
        WriteIndented = true
    };
    public override void Write<T>(Schedule[] obj, string path)
    {
        using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate))
        {
            JsonSerializer.Serialize(fs, obj, options);
        }
    }
    public override T Read<T>(string path)
    {
        using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate))
        {
            return JsonSerializer.Deserialize<T>(fs);
        }
    }
}