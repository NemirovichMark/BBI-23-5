﻿class Program
{
    static void Main()
    {
        Schedule[] weekSchedules = new Schedule[5];
        for (int i = 0; i < 5; i++)
        {
            weekSchedules[i] = new Schedule();
        }
        MyJsonSerializer serializer = new MyJsonSerializer();
        string[] files = new string[]
        {
            "raw_data.json",
            "data.json",
            "new_data.json"
        };
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string[] paths = new string[3];
        for(int i = 0; i < 3; i++)
        {
            paths[i] = Path.Combine(path, files[i]);
            if (!Directory.Exists(paths[i])) Directory.CreateDirectory(paths[i]);
        }
        serializer.Write<Schedule[]>(weekSchedules, paths[0]);
        DateTime startTime = new DateTime(2024, 1, 1, 8, 30, 0);
        DateTime currentTime = startTime;
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                Class newClass = new Class($"Lesson {j + 1}", $"Description of Lesson {j + 1}", currentTime, $"Room {j + 1}");
                weekSchedules[i].Add(newClass);
                currentTime = currentTime.Add(newClass.LessonLength);
                if (j < 4)
                {
                    Break newBreak = new Break($"Break {j + 1}", "Break", currentTime, false);
                    weekSchedules[i].Add(newBreak);
                    currentTime = currentTime.Add(newBreak.BreakLength);
                }
            }
            currentTime = startTime.Add(new TimeSpan(24, 0, 0));
        }
        serializer.Write<Schedule[]>(weekSchedules, paths[1]);

        for (int i = 0; i < 5; i++)
        {
            if (weekSchedules[i].Items[5] is Break breakItem)
            {
                breakItem.BreakLength = breakItem.BreakLength.Multiply(1.5);
            }
        }

        weekSchedules[4].Remove();

        DateTime time = weekSchedules[1].Items.Last().EndTime;
        weekSchedules[1].Add(new Class($"Lesson 6", $"Description of Lesson 6", time, $"Room 6"));
        serializer.Write<Schedule[]>(weekSchedules, paths[2]);

        string[] days = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" };
        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine($"{days[i]} Schedule:");
            weekSchedules[i].PrintInfo();
        }
        Console.WriteLine("----");
        for (int i = 0; i < 3; i++)
        {
            weekSchedules = serializer.Read<Schedule[]>(paths[i]);
            foreach(var schedule in weekSchedules)
            {
                schedule.PrintInfo();
            }
        }
    }
}