﻿using System;
using System.Text.Json;
using System.Text.Json.Serialization;

public class ScheduleItem
{
    protected string title;
    protected string description;
    protected DateTime startTime;
    protected DateTime endTime;
    public string Title
    {
        get { return title; }
        set { title = value; }
    }
    public string Description
    {
        get { return description; }
        set { description = value; }
    }
    public DateTime StartTime
    {
        get { return endTime; }
        set { endTime = value; }
    }
    public DateTime EndTime
    {
        get { return endTime; }
        set { endTime = value; }
    }
    public ScheduleItem(string title, string description, DateTime startTime)
    {
        this.title = title;
        this.description = description;
        this.startTime = startTime;
    }
    public override string ToString()
    {
        return $"{title}, {description}, {startTime} - {endTime}";
    }
}
class Class : ScheduleItem
{
    protected string classroom;
    protected TimeSpan lessonLength;
    public string Classroom
    {
        get { return classroom; }
        set { classroom = value; }
    }
    public TimeSpan LessonLength
    {
        get { return lessonLength; }
        set
        {
            lessonLength = value;
            endTime = startTime.Add(lessonLength);
        }
    }
    public Class(string title, string description, DateTime startTime, string classroom) : base(title, description, startTime)
    {
        this.classroom = classroom;
        lessonLength = TimeSpan.FromMinutes(45);
        endTime = startTime.Add(lessonLength);
    }
    public override string ToString()
    {
        return $"{title} in {classroom}: {description} from {startTime.ToShortTimeString()} to {endTime.ToShortTimeString()}"; ;
    }
}
class Break : ScheduleItem
{
    protected bool isLunch;
    protected TimeSpan breakLength;
    public bool IsLunch
    {
        get { return isLunch; }
        set { isLunch = value; }
    }
    public TimeSpan BreakLength
    {
        get { return breakLength; }
        set
        {
            breakLength = value;
            endTime = startTime.Add(breakLength);
        }
    }
    public Break(string title, string description, DateTime startTime, bool isLunch) : base(title, description, startTime)
    {
        this.isLunch = isLunch;
        if (isLunch)
        {
            this.description = "Lunch";
            breakLength = TimeSpan.FromMinutes(20);
        }
        else
        {
            this.description = "Short break";
            breakLength = TimeSpan.FromMinutes(15);
        }
        endTime = startTime.Add(breakLength);
    }
    public override string ToString()
    {
        return $"{title} ({description}): from {startTime.ToShortTimeString()} to {endTime.ToShortTimeString()}";
    }
}