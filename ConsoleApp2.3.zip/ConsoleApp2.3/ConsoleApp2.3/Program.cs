﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ConsoleApp2._3
{
    /*
    public abstract class SerializerHelper
    {
        public abstract void SerializeTo<T>(T obj, string filePath); // вместо T будет подставляться нужный тип, который мы передаем из main
        public abstract T DeserializeFrom<T>(string filePath);// вместо T будет подставляться нужный тип, который мы хотим получить в main
    }
    public class JsonSerializerHelper : SerializerHelper
    {
        public override void SerializeTo<T>(T obj, string filePath)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate))
            {
                JsonSerializer.Serialize(fs, obj);
            }
            // string json = JsonConvert.SerializeObject(obj);
            // File.WriteAllText(filePath, json);
        }

        public override T DeserializeFrom<T>(string filePath)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate))
            {
                return JsonSerializer.Deserialize<T>(fs);
            }
            return default(T);
            //   string json = File.ReadAllText(filePath);
            //   return JsonConvert.DeserializeObject<T>(json);
        }
    }
    public class XmlSerializerHelper : SerializerHelper
    {
        public override void SerializeTo<T>(T obj, string filePath)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));

            using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
            {
                serializer.Serialize(fileStream, obj);
            }
        }

        public override T DeserializeFrom<T>(string filePath)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));

            using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
            {
                return (T)serializer.Deserialize(fileStream);
            }
        }
    }

    public class ProtobufSerializerHelper : SerializerHelper
    {
        public override void SerializeTo<T>(T obj, string filePath)
        {
            using (var file = File.Create(filePath))
            {
                Serializer.Serialize(file, obj);
            }
        }

        public override T DeserializeFrom<T>(string filePath)
        {
            using (var file = File.OpenRead(filePath))
            {
                return Serializer.Deserialize<T>(file);
            }
        }
    }
    */

   
    [ProtoBuf.ProtoContract()]
    [ProtoBuf.ProtoInclude(1, typeof(JumpL))]
    [ProtoBuf.ProtoInclude(2, typeof(JumpH))]
    [XmlInclude(typeof(Disciplina))]
    [XmlInclude(typeof(JumpL))]
    [XmlInclude(typeof(JumpH))]
    [Serializable]
    abstract public class Disciplina
    {
        [ProtoMember(3)]
        [XmlAttribute]
        public string _namedis { get;  set; }
        [ProtoMember(4)]
        [XmlAttribute]
        public string _famile { get;  set; }
        [ProtoMember(5)]
        [XmlAttribute]
        public double[] _tests { get;  set; }
        [ProtoMember(6)]
        [XmlAttribute]
        public double _best { get;  set; }
        // public double best => _best;

        public Disciplina()   { }
        [JsonConstructor]
        public Disciplina(string _Namedis, string _Famile, double[] _Tests, double _Best)
        {
            _namedis = _Namedis;
            _famile = _Famile;

            _tests = _Tests;
            _best = _Tests[0];
            for (int i = 1; i < _Tests.Length; i++)
            {
                if (_Tests[i] > _best)
                {
                    _best = _Tests[i];
                }
            }

        }
        public virtual void Print()
        {
            Console.Write($"{_famile,-15}");
            for (int i = 0; i < _tests.Length; i++)
            {
                Console.Write(" {0:f2}", _tests[i]);
            }

            Console.WriteLine("   {0:f2}", _best);

        }
        public virtual void PrintTitle()
        {
            Console.WriteLine("Название дисциплины: {0}", _namedis);
            Console.WriteLine("Фамилия            Попытки      Лучший Рез.");

        }
    }
    [ProtoBuf.ProtoContract()]
    public class JumpL : Disciplina
    {

       public const  string _Namedis = "Прыжок в длину";
        public JumpL() { }
        [JsonConstructor]
        public JumpL(string _Famile, double[] _Tests) : base(_Namedis, _Famile, _Tests, 0)
        {


        }

    }
    [ProtoBuf.ProtoContract()]
    public class JumpH : Disciplina
    {

        public const string _Namedis = "Прыжок в высоту";
        public JumpH() { }
        [JsonConstructor]
        public JumpH(string _Famile, double[] _Tests) : base(_Namedis, _Famile, _Tests, 0)
        {
        }
    }
    internal class Program
    {
       static void Main(string[] args)
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            desktopPath += @"\WorkData\";
            if (!Directory.Exists(desktopPath))
            {
                Directory.CreateDirectory(desktopPath);
            }

            JumpL[] rezultsL = new JumpL[] {
            new JumpL("Иванова", new double[] { 5.56, 5.83, 5.73 }),
            new JumpL("Петрова", new double[] { 5.96, 5.75, 5.78 }),
            new JumpL("Сидорова", new double[] { 5.76, 6.02, 5.99 }),
            new JumpL("Ковальчук", new double[] { 5.86, 6.01, 5.97 }),
            new JumpL("Морозова", new double[] { 5.96, 5.83, 5.75 }),
            new JumpL("Травина", new double[] { 5.86, 5.85, 5.78 }),
            new JumpL("Семенова", new double[] { 5.76, 6.01, 5.89 }),
            new JumpL("Фургал", new double[] { 5.89, 5.93, 5.97 })
            };
            JumpH[] rezultsH = new JumpH[]{
            new JumpH("Иванова", new double[] { 2.06, 1.83, 2.30 }),
            new JumpH("Петрова", new double[] { 1.96, 1.75, 1.78 }),
            new JumpH("Сидорова", new double[] { 2.26, 1.98, 2.40 }),
            new JumpH("Морозова", new double[] { 1.97, 1.83, 2.35 }),
            new JumpH("Ковальчук", new double[] { 2.32, 2.21, 2.39})
            };
            string pathLjs = Path.Combine(desktopPath, "JumpL.json");
            string pathLxml = Path.Combine(desktopPath, "JumpL.xml");
            string pathLbin = Path.Combine(desktopPath, "JumpL.bin");
            string pathHjs = Path.Combine(desktopPath, "JumpH.json");
            string pathHxml = Path.Combine(desktopPath, "JumpH.xml");
            string pathHbin = Path.Combine(desktopPath, "JumpH.bin");
            ToWork(rezultsL);

            var jsoner = new JsonSerializerHelper();
            // Сериализация объекта в JSON файл
            jsoner.SerializeTo(rezultsL, pathLjs);
            Console.WriteLine($"Записаны данные в {pathLjs}");

           var xmler = new XmlSerializerHelper();
            // Сериализация объекта в XML файл
            xmler.SerializeTo(rezultsL, pathLxml);
            Console.WriteLine($"Записаны данные в {pathLxml}");

            var biner = new ProtobufSerializerHelper();
            // Сериализация объекта в JSON файл
            biner.SerializeTo(rezultsL, pathLbin);
            Console.WriteLine($"Записаны данные в {pathLbin}");


            JumpL[] rezultsLNew = jsoner.DeserializeFrom<JumpL[]>(pathLjs);
            if (rezultsLNew != null)
            {
                Console.WriteLine($"Считаны данные из {pathLjs}");
                foreach (JumpL cr5 in rezultsLNew)
                {
                    Console.WriteLine($"Disz: {cr5._namedis}, Name: {cr5._famile}, Rez: {cr5._tests[0]} {cr5._tests[1]} {cr5._tests[2]}, Best {cr5._best}");
                }
                ToWork(rezultsLNew);
            }
            else
            {
                Console.WriteLine("Ошибка десериализации.");
            }


             rezultsLNew = biner.DeserializeFrom<JumpL[]>(pathLbin);
             if (rezultsLNew != null)
             {
                 Console.WriteLine($"Считаны данные из {pathLbin}");
                 foreach (JumpL cr5 in rezultsLNew)
                 {
                     Console.WriteLine($"Disz: {cr5._namedis}, Name: {cr5._famile}, Rez: {cr5._tests[0]} {cr5._tests[1]} {cr5._tests[2]}, Best {cr5._best}");
                 }
                 ToWork(rezultsLNew);
             }
             else
             {
                 Console.WriteLine("Ошибка десериализации.");
             }

            rezultsLNew = jsoner.DeserializeFrom<JumpL[]>(pathLjs);
            if (rezultsLNew != null)
            {
                Console.WriteLine($"Считаны данные из {pathLjs}");
                foreach (JumpL cr5 in rezultsLNew)
                {
                    Console.WriteLine($"Disz: {cr5._namedis}, Name: {cr5._famile}, Rez: {cr5._tests[0]} {cr5._tests[1]} {cr5._tests[2]}, Best {cr5._best}");
                }
                ToWork(rezultsLNew);
            }
            else
            {
                Console.WriteLine("Ошибка десериализации.");
            }

            ToWork(rezultsH);

            jsoner = new JsonSerializerHelper();
            // Сериализация объекта в JSON файл
            jsoner.SerializeTo(rezultsL, pathHjs);
            Console.WriteLine($"Записаны данные в {pathHjs}");

            xmler = new XmlSerializerHelper();
                        // Сериализация объекта в XML файл
                        xmler.SerializeTo(rezultsH, pathHxml);
                        Console.WriteLine($"Записаны данные в {pathHxml}");

             biner = new ProtobufSerializerHelper();
            // Сериализация объекта в JSON файл
            biner.SerializeTo(rezultsH, pathHbin);
            Console.WriteLine($"Записаны данные в {pathHbin}");


            JumpH[] rezultsHNew = jsoner.DeserializeFrom<JumpH[]>(pathHjs);
            if (rezultsHNew != null)
            {
                Console.WriteLine($"Считаны данные из {pathHjs}");
                foreach (JumpH cr5 in rezultsHNew)
                {
                    Console.WriteLine($"Disz: {cr5._namedis}, Name: {cr5._famile}, Rez: {cr5._tests[0]} {cr5._tests[1]} {cr5._tests[2]}, Best {cr5._best}");
                }
                ToWork(rezultsLNew);
            }
            else
            {
                Console.WriteLine("Ошибка десериализации.");
            }

             rezultsHNew = biner.DeserializeFrom<JumpH[]>(pathHbin);
             if (rezultsHNew != null)
             {
                 Console.WriteLine($"Считаны данные из {pathHbin}");
                 foreach (JumpH cr5 in rezultsHNew)
                 {
                     Console.WriteLine($"Disz: {cr5._namedis}, Name: {cr5._famile}, Rez: {cr5._tests[0]} {cr5._tests[1]} {cr5._tests[2]}, Best {cr5._best}");
                 }
                 ToWork(rezultsHNew);
             }
             else
             {
                 Console.WriteLine("Ошибка десериализации.");
             }
            rezultsHNew = jsoner.DeserializeFrom<JumpH[]>(pathHjs);
            if (rezultsHNew != null)
            {
                Console.WriteLine($"Считаны данные из {pathHjs}");
                foreach (JumpH cr5 in rezultsHNew)
                {
                    Console.WriteLine($"Disz: {cr5._namedis}, Name: {cr5._famile}, Rez: {cr5._tests[0]} {cr5._tests[1]} {cr5._tests[2]}, Best {cr5._best}");
                }
                ToWork(rezultsHNew);
            }
            else
            {
                Console.WriteLine("Ошибка десериализации.");
            }


        }
        static void Sort(Disciplina[] rezults)
        {
            int imax;
            for (int i = 0; i < rezults.Length - 1; i++)
            {
                imax = i;

                for (int j = i + 1; j < rezults.Length; j++)
                {
                    if (rezults[j]._best > rezults[imax]._best)
                    {
                        imax = j;
                    }
                }
                Disciplina spTemp = rezults[i];
                rezults[i] = rezults[imax];
                rezults[imax] = spTemp;
            }
        }
        static void OutMas(Disciplina[] rezults)
        {
            Console.WriteLine();
            rezults[0].PrintTitle();
            foreach (Disciplina tmp in rezults)
            {
                tmp.Print();
            }
        }
        static void ToWork(Disciplina[] rezults)
        {
            Console.WriteLine("Исходные данные");
            OutMas(rezults);
            Sort(rezults);
            Console.WriteLine("После обработки");
            OutMas(rezults);
        }
    }
}
