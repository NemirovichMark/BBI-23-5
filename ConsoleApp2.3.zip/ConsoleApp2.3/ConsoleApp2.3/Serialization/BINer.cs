
using System.IO;
using ProtoBuf;


    class ProtobufSerializerHelper : SerializerHelper
    {
        public override void SerializeTo<T>(T obj, string filePath)
        {
            using (var file = File.Create(filePath))
            {
                Serializer.Serialize(file, obj);
            }
        }

        public override T DeserializeFrom<T>(string filePath)
        {
            using (var file = File.OpenRead(filePath))
            {
                return Serializer.Deserialize<T>(file);
            }
        }
    }
