﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Lab_10
{
    [XmlInclude(typeof(Series))]
    [XmlInclude(typeof(Cartoon))]
    public partial class Movie
    {
        public string Title { get; set; }
        public string Director { get; set; }
        public DateTime Year { get; set; } // можно было и как int взять 
        public float Rating { get; set; }
        public TimeSpan Length { get; set; }

        public Movie()
        {
        }

        public Movie(string title, string director, DateTime year, float rating, TimeSpan length)
        {
            Title = title;
            Director = director;
            Year = year;
            Rating = rating;
            Length = length;
        }

        public override string ToString()
        {
            var str = "";

            str += $"Название: {Title} ";
            str += $"Режиссёр: {Director} ";
            str += $"Год: {Year.Year} ";
            str += $"Рейтинг: {Rating} ";
            str += $"Длительность: {Length.Hours}:{Length.Minutes} ";

            return str;
        }
    }
}