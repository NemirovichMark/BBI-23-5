﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_10
{
    public partial class Movie
    {
        public static void SortByTitle(Movie[] movies)
        {
            int n = movies.Length;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {
                    if (movies[j] != null && movies[j + 1] != null)
                    {
                        if (_stringCompare(movies[j].Title, movies[j + 1].Title) > 0)
                        {
                            Movie temp = movies[j];
                            movies[j] = movies[j + 1];
                            movies[j + 1] = temp;
                        }
                    }
                }
            }
        }

        private static int _stringCompare(string str1, string str2)
        {
            return string.Compare(str1, str2, StringComparison.CurrentCulture);
        }

        public static void SortByDate(Movie[] movies)
        {
            int n = movies.Length;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {
                    if (movies[j] != null && movies[j + 1] != null)
                    {
                        if (movies[j].Year > movies[j + 1].Year)
                        {
                            Movie temp = movies[j];
                            movies[j] = movies[j + 1];
                            movies[j + 1] = temp;
                        }
                    }
                }
            }
        }
    }
}
