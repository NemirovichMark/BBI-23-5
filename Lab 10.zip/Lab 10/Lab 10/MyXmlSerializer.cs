﻿using System;
using System.Xml.Serialization;

namespace Lab_10
{
    internal class MyXmlSerializer : MySerializer
    {
        public override T? Deserialize<T>(string fileName) where T : default
        {
            StreamReader reader = new StreamReader(fileName);
            var s = new XmlSerializer(typeof(T));

            T result = (T)s.Deserialize(reader);
            reader.Dispose();

            return result;
        }

        public override void Serialize(object @object, string fileName)
        {
            XmlSerializer serializer = new XmlSerializer(@object.GetType());
            StreamWriter writer = new StreamWriter(fileName);
            serializer.Serialize(writer, @object);
            writer.Dispose();
        }
    }
}

