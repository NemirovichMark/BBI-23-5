﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_10
{
    public interface IMoviesList
    {
        public Movie[] Movies { get; }

        void AddMovie(Movie movie);
        void RemoveMovie(Movie movie);
        void AddMovies(Movie[] movies);
        void RemoveMovieById(int id);
        void DisplayList();
    }
}
