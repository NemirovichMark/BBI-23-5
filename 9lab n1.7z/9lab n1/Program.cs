﻿using System;
using System.IO;
using System.Text.Json;
using System.Xml.Serialization;
using ProtoBuf;
using static Program;

[ProtoContract]
class Program
{
    [ProtoContract]
    public class Uchastnik
    {
        [ProtoMember(1)]
        public string Lastname { get; protected set; }
        [ProtoMember(2)]
        public string Obzhestvo { get; protected set; }
        [ProtoMember(3)]
        public double Result1 { get; protected set; }
        [ProtoMember(4)]
        public double Result2 { get; protected set; }
        [ProtoMember(5)]
        public double Summ { get; protected set; }
        [ProtoMember(6)]
        public bool Disqualified { get; protected set; }

        public Uchastnik() { } // Parameterless constructor needed for serialization.

        public Uchastnik(string ln, string obzh, double r1, double r2)
        {
            Lastname = ln;
            Obzhestvo = obzh;
            Result1 = r1;
            Result2 = r2;
            Summ = r1 + r2;
            Disqualified = false;
        }

        public void Disqualify()
        {
            Disqualified = true;
        }
    }

    public abstract class Serializer<T>
    {
        public abstract void Serialize(string filePath, T data);
        public abstract T Deserialize(string filePath);
    }

    public class JsonSerializer<T> : Serializer<T>
    {
        public override void Serialize(string filePath, T data)
        {
            string jsonData = JsonSerializer.Serialize(data);
            File.WriteAllText(filePath, jsonData);
        }

        public override T Deserialize(string filePath)
        {
            string jsonData = File.ReadAllText(filePath);
            return JsonSerializer.Deserialize<T>(jsonData);
        }
    }

    public class XmlSerializer<T> : Serializer<T>
    {
        public override void Serialize(string filePath, T data)
        {
            var serializer = new System.Xml.Serialization.XmlSerializer(typeof(T));
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                serializer.Serialize(stream, data);
            }
        }

        public override T Deserialize(string filePath)
        {
            var serializer = new System.Xml.Serialization.XmlSerializer(typeof(T));
            using (var stream = new FileStream(filePath, FileMode.Open))
            {
                return (T)serializer.Deserialize(stream);
            }
        }
    }

    public class BinarySerializer<T> : Serializer<T>
    {
        public override void Serialize(string filePath, T data)
        {
            using (var file = File.Create(filePath))
            {
                Serializer.Serialize(file, data);
            }
        }

        public override T Deserialize(string filePath)
        {
            using (var file = File.OpenRead(filePath))
            {
                return Serializer.Deserialize<T>(file);
            }
        }
    }

    static void PrintUch(Uchastnik[] uchastniks)
    {
        Console.WriteLine("Фамилия    Общество   FA    SA    Сумма"); //FA-first attempt, SA-second attempt.
        foreach (var uchastnik in uchastniks)
        {
            if (!uchastnik.Disqualified)
            {
                Console.WriteLine($"{uchastnik.Lastname}    {uchastnik.Obzhestvo}  {uchastnik.Result1}    {uchastnik.Result2,-2}    {uchastnik.Summ}");
            }
        }
    }

    static void Main()
    {
        Uchastnik[] uchastniks = {
            new Uchastnik("Петров","общество1",8.1,7.3),
            new Uchastnik("Иванов","общество2",7.5, 7.1),
            new Uchastnik("Сидоров","общество3",6.7,6.3),
            new Uchastnik("Крутов", "общество4",7.7,7.8),
            new Uchastnik("Молодов","общество5",7.2,6.9),
        };

        uchastniks[2].Disqualify(); // Disqualify participant Сидорова

        // Serialization
        var jsonSerializer = new JsonSerializer<Uchastnik[]>();
        jsonSerializer.Serialize("SerializedData.json", uchastniks);

        var xmlSerializer = new XmlSerializer<Uchastnik[]>();
        xmlSerializer.Serialize("SerializedData.xml", uchastniks);

        var binarySerializer = new BinarySerializer<Uchastnik[]>();
        binarySerializer.Serialize("SerializedData.bin", uchastniks);

        // Deserialization
        var deserializedJson = jsonSerializer.Deserialize("SerializedData.json");
        var deserializedXml = xmlSerializer.Deserialize("SerializedData.xml");
        var deserializedBinary = binarySerializer.Deserialize("SerializedData.bin");

        // Printing deserialized data
        Console.WriteLine("\nDeserialized Data:");
        PrintUch(deserializedJson);
        PrintUch(deserializedXml);
        PrintUch(deserializedBinary);
    }
}