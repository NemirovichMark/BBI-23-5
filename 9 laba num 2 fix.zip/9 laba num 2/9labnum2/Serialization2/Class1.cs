﻿using System.Runtime.Serialization.Formatters.Binary;
using System.Text.Json.Serialization;
using Newtonsoft.Json;
using System.Xml.Serialization;
#pragma warning disable SYSLIB0011



namespace Serialization2;

public class MySerialization
{
    public static void SerializeToJSON(object o, string path)
    {
        string json = JsonConvert.SerializeObject(o, Formatting.Indented);
        File.WriteAllText(path, json);
    }

    public static T DeserializeFromJSON<T>(string path)
    {
        string json = File.ReadAllText(path);
        return JsonConvert.DeserializeObject<T>(json);
    }

    public static void SerializeToXML<T>(T o, string path)
    {
        var serializer = new XmlSerializer(typeof(T));
        using (var stream = new FileStream(path, FileMode.Create))
        {
            serializer.Serialize(stream, o);
        }
    }

    public static T DeserializeFromXML<T>(string path)
    {
        var serializer = new XmlSerializer(typeof(T));
        using (var stream = new FileStream(path, FileMode.Open))
        {
            return (T)serializer.Deserialize(stream);
        }
    }

    public static void SerializeToBinary(object o, string path)
    {
        var formatter = new BinaryFormatter();
        using (var stream = new FileStream(path, FileMode.Create))
        {
            formatter.Serialize(stream, o);
        }
    }

    public static T DeserializeFromBinary<T>(string path)
    {
        var formatter = new BinaryFormatter();
        using (var stream = new FileStream(path, FileMode.Open))
        {
            return (T)formatter.Deserialize(stream);
        }
    }
}
