﻿using System;
using Newtonsoft.Json;
using Serialization2;

[Serializable]
public class Sportsmens
{
    [JsonProperty]
    public string _lastname;

    [JsonProperty]
    public double result1;

    [JsonProperty]
    public double result2;

    [JsonProperty]
    public double result3;

    public Sportsmens(string lastname, double res1, double res2, double res3)
    {
        _lastname = lastname;
        result1 = res1;
        result2 = res2;
        result3 = res3;
    }

    public Sportsmens() { }

    public string Lastname()
    {
        return _lastname;
    }

    public double Bestresult()
    {
        return Math.Max(result1, Math.Max(result2, result3));
    }

    public void Print()
    {
        Console.WriteLine($"Sportsmens: {Lastname()}");
        Console.WriteLine($"Best result: {Bestresult()}");
        Console.WriteLine();
    }
}
public abstract class Discipline
{
    public abstract string DisciplineName { get; }
    private Sportsmens[] _sportsmens;

    public Discipline(Sportsmens[] sportsmens)
    {
        _sportsmens = sportsmens;

    }

    public void Print()
    {

        Console.WriteLine($"Discipline: {DisciplineName}");
        foreach(var sportsmen in _sportsmens)
        {
            sportsmen.Print();
        }
        Console.WriteLine();

    }
}
public class LongJump : Discipline
{
    public override string DisciplineName => "прыжки в длину";
    public LongJump(Sportsmens [] sportsmens) : base(sportsmens)
    {

    }

}
public class HightJump : Discipline
{
    public override string DisciplineName => "прыжки в высоту";
    public HightJump(Sportsmens[] sportsmens) : base(sportsmens)
    {

    }
}


class Program
{
    static void Main()
    {
        Sportsmens[] longJump =
        {
            new Sportsmens("Евелькин", 4.9, 5.9, 6.0),
            new Sportsmens("Smith", 5.6, 5.8, 5.7),
            new Sportsmens("Johnson", 5.5, 5.9, 6.1),
            new Sportsmens("Носыч", 4.8, 7.1, 7.0),
            new Sportsmens("Мбапе", 4.9, 5.9, 6.1)
        };
        Sportsmens[] hightJump =
        {
            new Sportsmens("Олег", 1.5, 1.1, 1.0),
            new Sportsmens("Богдан Федунь", 2.0, 0.8, 2.0),
            new Sportsmens("Кунгуров", 1.5, 0.9, 2.1),
            new Sportsmens("Сацик", 1.8, 1.1, 2.0),
            new Sportsmens("Месси", 1.9, 1.9, 2.1)
        };
        Discipline[] disciplines =
        {
            new HightJump(hightJump),
            new LongJump(longJump)
        };

        Console.WriteLine("Final Results:");
        foreach (var discipline in disciplines)
        {
            discipline.Print();
        }

        string folderPath = "C:\\Users\\novik\\OneDrive\\Рабочий стол\\ser";
        string JSONPath = Path.Combine(folderPath, "Sportsmens.json");
        string XMLPath = Path.Combine(folderPath, "Sportsmens.xml");
        string BinaryPath = Path.Combine(folderPath, "Sportsmens.bin");

        MySerialization.SerializeToJSON(longJump, Path.Combine(folderPath, "longJump.json"));
        MySerialization.SerializeToJSON(hightJump, Path.Combine(folderPath, "hightJump.json"));

        Sportsmens[] longJumpFromJSON = MySerialization.DeserializeFromJSON<Sportsmens[]>(Path.Combine(folderPath, "longJump.json"));
        foreach (var player in longJumpFromJSON)
        {
            player.Print();
        }
        Console.Write(longJumpFromJSON);
        Console.WriteLine();

        Sportsmens[] hightJumpFromJSON = MySerialization.DeserializeFromJSON<Sportsmens[]>(Path.Combine(folderPath, "hightJump.json"));
        foreach (var player in hightJumpFromJSON)
        {
            player.Print();
        }
        Console.Write(hightJumpFromJSON);
        Console.WriteLine();

        MySerialization.SerializeToXML(longJump, Path.Combine(folderPath, "longJump.xml"));
        MySerialization.SerializeToXML(hightJump, Path.Combine(folderPath, "hightJump.xml"));

        Sportsmens[] longJumpFromXML = MySerialization.DeserializeFromXML<Sportsmens[]>(Path.Combine(folderPath, "longJump.xml"));
        foreach (var player in longJumpFromXML)
        {
            player.Print();
        }
        Console.Write(longJumpFromXML);
        Console.WriteLine();

        Sportsmens[] hightJumpFromXML = MySerialization.DeserializeFromXML<Sportsmens[]>(Path.Combine(folderPath, "hightJump.xml"));
        foreach (var player in hightJumpFromXML)
        {
            player.Print();
        }
        Console.Write(hightJumpFromXML);
        Console.WriteLine();

        MySerialization.SerializeToBinary(longJump, Path.Combine(folderPath, "longJump.bin"));
        MySerialization.SerializeToBinary(hightJump, Path.Combine(folderPath, "hightJump.bin"));

        Sportsmens[] longJumpFromBinary = MySerialization.DeserializeFromBinary<Sportsmens[]>(Path.Combine(folderPath, "longJump.bin"));
        foreach (var player in longJumpFromBinary)
        {
            player.Print();
        }
        Console.Write(longJumpFromBinary);
        Console.WriteLine();

        Sportsmens[] hightJumpFromBinary = MySerialization.DeserializeFromBinary<Sportsmens[]>(Path.Combine(folderPath, "hightJump.bin"));
        foreach (var player in hightJumpFromBinary)
        {
            player.Print();
        }
        Console.Write(hightJumpFromBinary);
        Console.WriteLine();
    }
}