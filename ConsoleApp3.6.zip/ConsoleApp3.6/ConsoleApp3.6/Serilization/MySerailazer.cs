

    public abstract class SerializerHelper
    {
    public abstract void SerializeTo<T>(T obj, string filePath); // вместо T будет подставляться нужный тип, который мы передаем из main
    public abstract T DeserializeFrom<T>(string filePath);// вместо T будет подставляться нужный тип, который мы хотим получить в main
}
 