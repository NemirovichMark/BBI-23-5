﻿using System;
using System.IO;
using System.Text.Json.Serialization;
using System.Xml.Serialization;
using ProtoBuf;

//namespace ConsoleApp3._6
//{

public class Antw_rat
    {
   
    public string antw { get;  set; }
     
    public double rating { get;  set; }

        public Antw_rat() { }
        [JsonConstructor]
        public Antw_rat(string antw,double rating)
        {
            this.antw = antw;
            this.rating = rating;
        }
}
[ProtoBuf.ProtoContract()]
[ProtoBuf.ProtoInclude(1, typeof(Russia))]
[ProtoBuf.ProtoInclude(2, typeof(Japan))]
[ProtoBuf.ProtoInclude(3, typeof(CommonL))]
[XmlInclude(typeof(Strana))]
[XmlInclude(typeof(Russia))]
[XmlInclude(typeof(CommonL))]
abstract public class Strana
    {
        [ProtoMember(4)]
        [XmlAttribute]
    public string _nameCountry { get;  set; }
        [ProtoMember(5)]
         [XmlAttribute]
    public string _frage { get;  set; }
        [ProtoMember(6)]
    [XmlAttribute]
    public string[] _antwort { get;  set; }
        [ProtoMember(7)]
    [XmlElement]
    public Antw_rat[] antwort_rating { get;  set; }
        [ProtoMember(8)]
    [XmlAttribute]
    public int _num_rats { get;  set; }
        public Strana() { } 
        [JsonConstructor]
        public Strana(string _NameCountry, string _Frage, string[] _Antwort, Antw_rat[] Antwort_rating,int _Num_rats)
        {
            _nameCountry = _NameCountry;
            _frage = _Frage;
            _antwort = _Antwort;
        }
        public void PrintData()
        {
            Console.WriteLine("Вопрос: {0} {1}?", _frage, _nameCountry);
            for (int i = 0; i < _antwort.Length; i++)
            {
                Console.WriteLine($"{_antwort[i],-20}");

            }
        }
        public void PrintRating()
        {
            Antw_rat[] antwort_rating = new Antw_rat[40];
            int _num_rats = 1;
            for (int i = 0; i < _antwort.Length; i++)
                antwort_rating[i] = new Antw_rat();
            antwort_rating[0] =new Antw_rat(_antwort[0], 0);
            bool fnd;
            for (int i = 1; i < _antwort.Length; i++)     //отбор уникальных значений
            {
                fnd = false;
                for (int j = 0; j < _num_rats; j++)
                {
                    if (_antwort[i] == antwort_rating[j].antw)
                    {
                        fnd = true;
                        break;
                    }

                }
                if (!fnd)
                {
                    //   antwort_rating[_num_rats].antw = _antwort[i];
                    //  antwort_rating[_num_rats].rating = 0;
                    antwort_rating[_num_rats] = new Antw_rat(_antwort[i], 0);

                    _num_rats++;
                }
            }

            for (int i = 0; i < _antwort.Length; i++)     //составление рейтинга
            {
                for (int j = 0; j < _num_rats; j++)
                {
                    if (_antwort[i] == antwort_rating[j].antw)
                    {
                        //  antwort_rating[j].rating = antwort_rating[j].rating + 1;
                        antwort_rating[j] = new Antw_rat(antwort_rating[j].antw,antwort_rating[j].rating + 1);
                        break;
                    }
                }
            }

            int imax; Antw_rat max;
            for (int i = 0; i < _num_rats - 1; i++)     //сортировка
            {
                imax = i;
                for (int j = i + 1; j < _num_rats; j++)
                {
                    if (antwort_rating[i].rating < antwort_rating[j].rating)
                    {
                        imax = j;
                    }

                }
                max = antwort_rating[i];
                antwort_rating[i] = antwort_rating[imax];
                antwort_rating[imax] = max;
            }

            if (_num_rats > 5) { _num_rats = 5; }

            Console.WriteLine("-----------Рейтинг----------");
            for (int i = 0; i < _num_rats; i++)
            {
                Console.Write($"{antwort_rating[i].antw,-20}");
                Console.WriteLine("{0,6:f2} %", antwort_rating[i].rating * 100 / _antwort.Length);

            }
            Console.WriteLine("===========================");
        }

    }
[ProtoBuf.ProtoContract()]
public class Russia : Strana
    {

        public const string _NameCountry = "Россия";
        public Russia() { }
        [JsonConstructor]
        public Russia(string _Frage, string[] _Antwort) : base(_NameCountry, _Frage, _Antwort,null,0)
        {


        }

    }
[ProtoBuf.ProtoContract()]
public class Japan : Strana
    {
         public const string _NameCountry = "Япония";
        public Japan() { }
     
        [JsonConstructor]
        public Japan(string _Frage, string[] _Antwort) : base(_NameCountry, _Frage, _Antwort, null, 0)
        {
        }
    }
[ProtoBuf.ProtoContract()]
public class CommonL : Strana
    {

        public const string _NameCountry = "Россия + Япония";
        public CommonL() { }
        [JsonConstructor]

        public CommonL(string _Frage, string[] _Antwort) : base(_NameCountry, _Frage, _Antwort, null, 0)
        {
        }

    }
    internal class Program
    {
        static void Main(string[] args)
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            desktopPath += @"\WorkData\";
            if (!Directory.Exists(desktopPath))
            {
                Directory.CreateDirectory(desktopPath);
            }
            String[,] dataY = new string[20, 3]
                    {{ "журавль","исполнительность","остров" },
                    { "тигр","исполнительность","икебана" },
                    { "фазан","миролюбие","икебана" },
                    { "фазан","миролюбие","остров" },
                    { "кошка","исполнительность","остров" },
                    { "журавль","трудолюбие","остров" },
                    { "дракон","исполнительность","остров" },
                    { "тануки","","икебана" },
                    { "тануки","трудолюбие","икебана" },
                    { "журавль","исполнительность","икебана" },
                    { "тануки","миролюбие","катана" },
                    { "тигр","исполнительность","" },
                    { "фазан","вежливость","сакура" },
                    { "фазан","вежливость","катана" },
                    { "кошка","вежливость","сакура" },
                    { "журавль","исполнительность","" },
                    { "дракон","миролюбие","сакура" },
                    { "тануки","исполнительность","саке" },
                    { "тануки","вежливость","саке" },
                    { "тануки","вежливость","катана" }
                    };
            String[,] dataR = new string[20, 3]
                    {{ "медведь","находчивость","водка" },
                    { "заяц","смелость","самовар" },
                    { "лиса","щедрость","матрешка" },
                    { "бобр","находчивость","ушанка" },
                    { "бобр","находчивость","зима" },
                    { "медведь","находчивость","матрешка" },
                    { "орел","смелость","ушанка" },
                    { "медведь","","матрешка" },
                    { "олень","находчивость","зима" },
                    { "медведь","смелость","матрешка" },
                    { "медведь","","катана" },
                    { "олень","смелость","" },
                    { "медведь","отвага","водка" },
                    { "фазан","отвага","зима" },
                    { "олень","вежливость","водка" },
                    { "бобр","","" },
                    { "медведь","щедрость","матрешка" },
                    { "заяц","трудолюбие","самовар" },
                    { "заяц","честность","матрешка" },
                    { "лиса","отвага","самовар" }
                    };

            string[] masOtvY = new string[20];
            for (int i = 0; i < masOtvY.Length; i++)
                masOtvY[i] = dataY[i, 0];

            Japan vopr1Y = new Japan("Какое животное вы связываете со страной ", masOtvY);
            vopr1Y.PrintData();
            vopr1Y.PrintRating();

            string[] masOtvR = new string[20];
            for (int i = 0; i < masOtvR.Length; i++)
                masOtvR[i] = dataR[i, 0];

            Russia vopr1R = new Russia("Какое животное вы связываете со страной ", masOtvR);
            vopr1R.PrintData();
            vopr1R.PrintRating();
            string[] masOtvC = new string[40];
            CommonArray(masOtvY, masOtvR, masOtvC);


            CommonL vopr1C = new CommonL("Какое животное вы связываете со страной ", masOtvC);
            vopr1C.PrintData();
            vopr1C.PrintRating();

            for (int i = 0; i < masOtvY.Length; i++)
                masOtvY[i] = dataY[i, 1];

            Japan vopr2Y = new Japan("Какая черта характера присуща больше всего жителям страны ", masOtvY);
            vopr2Y.PrintData();
            vopr2Y.PrintRating();

            for (int i = 0; i < masOtvR.Length; i++)
                masOtvR[i] = dataR[i, 1];

            Russia vopr2R = new Russia("Какая черта характера присуща больше всего жителям страны ", masOtvR);
            vopr2R.PrintData();
            vopr2R.PrintRating();

            CommonArray(masOtvY, masOtvR, masOtvC);
            CommonL vopr2C = new CommonL("Какая черта характера присуща больше всего жителям страны ", masOtvC);
            vopr2C.PrintData();
            vopr2C.PrintRating();

            for (int i = 0; i < masOtvY.Length; i++)
                masOtvY[i] = dataY[i, 2];

            Japan vopr3Y = new Japan("Какой неодушевленный предмет или понятия вы связываете со страной ", masOtvY);
            vopr3Y.PrintData();
            vopr3Y.PrintRating();

            for (int i = 0; i < masOtvR.Length; i++)
                masOtvR[i] = dataR[i, 2];

            Russia vopr3R = new Russia("Какой неодушевленный предмет или понятия вы связываете со страной ", masOtvR);
            vopr3R.PrintData();
            vopr3R.PrintRating();

            CommonArray(masOtvY, masOtvR, masOtvC);
            CommonL vopr3C = new CommonL("Какой неодушевленный предмет или понятия вы связываете со страной ", masOtvC);
            vopr3C.PrintData();
            vopr3C.PrintRating();

            string RussiaJs = Path.Combine(desktopPath, "Russia.json");
            string JapanJs = Path.Combine(desktopPath, "Japan.json");
            string CommonJs = Path.Combine(desktopPath, "Common.json");
            string RussiaBin = Path.Combine(desktopPath, "Russia.bin");
            string JapanBin = Path.Combine(desktopPath, "Japan.bin");
            string CommonBin = Path.Combine(desktopPath, "Common.bin");
            string RussiaXML = Path.Combine(desktopPath, "Russia.xml");
            string JapanXML= Path.Combine(desktopPath, "Japan.xml");
            string CommonXML = Path.Combine(desktopPath, "Common.xml");


        var jsoner = new JsonSerializerHelper();
        var biner = new ProtobufSerializerHelper();
        var xmler = new XmlSerializerHelper();

        // Сериализация объекта в JSON файл
        Russia[] voprR = new Russia[3];
            voprR[0] = vopr1R; voprR[1] = vopr2R; voprR[2] = vopr3R;

            Japan[] voprY = new Japan[3];
            voprY[0] = vopr1Y; voprY[1] = vopr2Y; voprY[2] = vopr3Y;

            CommonL[] voprC = new CommonL[3];
            voprC[0] = vopr1C; voprC[1] = vopr2C; voprC[2] = vopr3C;

            jsoner.SerializeTo(voprR, RussiaJs);
            Console.WriteLine($"Записаны данные в {RussiaJs}"); 
            
            jsoner.SerializeTo(voprY, JapanJs);
            Console.WriteLine($"Записаны данные в {JapanJs}");

            jsoner.SerializeTo(voprC, CommonJs);
            Console.WriteLine($"Записаны данные в {CommonJs}");

            biner.SerializeTo(voprR, RussiaBin);
            Console.WriteLine($"Записаны данные в {RussiaBin}");

            biner.SerializeTo(voprY, JapanBin);
            Console.WriteLine($"Записаны данные в {JapanBin}");

            biner.SerializeTo(voprC, CommonBin);
            Console.WriteLine($"Записаны данные в {CommonBin}");

            xmler.SerializeTo(voprR, RussiaXML);
            Console.WriteLine($"Записаны данные в {RussiaXML}");

            xmler.SerializeTo(voprY, JapanXML);
            Console.WriteLine($"Записаны данные в {JapanXML}");

            xmler.SerializeTo(voprC, CommonXML);
            Console.WriteLine($"Записаны данные в {CommonXML}");

        Console.WriteLine($"*******************");

            voprR = jsoner.DeserializeFrom<Russia[]>(RussiaJs);
            if (voprR != null)
            {
                Console.WriteLine($"Считаны данные из {RussiaJs}");
                for (int i = 0; i < voprR.Length; i++)
                {
                    voprR[i].PrintData();
                    voprR[i].PrintRating();
                }
            }
            else
            {
                Console.WriteLine("Ошибка десериализации.");
            }

            voprY = jsoner.DeserializeFrom<Japan[]>(JapanJs);
            if (voprY != null)
            {
                Console.WriteLine($"Считаны данные из {JapanJs}");
                for (int i = 0; i < voprY.Length; i++)
                {
                    voprY[i].PrintData();
                    voprY[i].PrintRating();
                }
            }
            else
            {
                Console.WriteLine("Ошибка десериализации.");
            }

            voprC = jsoner.DeserializeFrom<CommonL[]>(CommonJs);
            if (voprC != null)
            {
                Console.WriteLine($"Считаны данные из {CommonJs}");
                for (int i = 0; i < voprC.Length; i++)
                {
                    voprC[i].PrintData();
                    voprC[i].PrintRating();
                }
            }
            else
            {
                Console.WriteLine("Ошибка десериализации.");
            }

        voprR = biner.DeserializeFrom<Russia[]>(RussiaBin);
        if (voprR != null)
        {
            Console.WriteLine($"Считаны данные из {RussiaBin}");
            for (int i = 0; i < voprR.Length; i++)
            {
                voprR[i].PrintData();
                voprR[i].PrintRating();
            }
        }
        else
        {
            Console.WriteLine("Ошибка десериализации.");
        }
        voprY = biner.DeserializeFrom<Japan[]>(JapanBin);
        if (voprY != null)
        {
            Console.WriteLine($"Считаны данные из {JapanBin}");
            for (int i = 0; i < voprY.Length; i++)
            {
                voprY[i].PrintData();
                voprY[i].PrintRating();
            }
        }
        else
        {
            Console.WriteLine("Ошибка десериализации.");
        }

        voprC = biner.DeserializeFrom<CommonL[]>(CommonBin);
        if (voprC != null)
        {
            Console.WriteLine($"Считаны данные из {CommonBin}");
            for (int i = 0; i < voprC.Length; i++)
            {
                voprC[i].PrintData();
                voprC[i].PrintRating();
            }
        }
        else
        {
            Console.WriteLine("Ошибка десериализации.");
        }

        voprR = xmler.DeserializeFrom<Russia[]>(RussiaXML);
        if (voprR != null)
        {
            Console.WriteLine($"Считаны данные из {RussiaXML}");
            for (int i = 0; i < voprR.Length; i++)
            {
                voprR[i].PrintData();
                voprR[i].PrintRating();
            }
        }
        else
        {
            Console.WriteLine("Ошибка десериализации.");
        }
        voprY = xmler.DeserializeFrom<Japan[]>(JapanXML);
        if (voprY != null)
        {
            Console.WriteLine($"Считаны данные из {JapanXML}");
            for (int i = 0; i < voprY.Length; i++)
            {
                voprY[i].PrintData();
                voprY[i].PrintRating();
            }
        }
        else
        {
            Console.WriteLine("Ошибка десериализации.");
        }

        voprC = xmler.DeserializeFrom<CommonL[]>(CommonXML);
        if (voprC != null)
        {
            Console.WriteLine($"Считаны данные из {CommonXML}");
            for (int i = 0; i < voprC.Length; i++)
            {
                voprC[i].PrintData();
                voprC[i].PrintRating();
            }
        }
        else
        {
            Console.WriteLine("Ошибка десериализации.");
        }

    }
    static void CommonArray(string[] mas1, string[] mas2, string[] masCommon)
        {
            for (int i = 0; i < mas1.Length; i++)
                masCommon[i] = mas1[i];
            int n = mas1.Length;
            for (int i = n; i < n + mas2.Length; i++)
                masCommon[i] = mas2[i - n];
        }
    }
//}
