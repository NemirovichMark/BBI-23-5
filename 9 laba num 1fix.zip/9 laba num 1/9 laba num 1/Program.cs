﻿//номер 1 первый уровень
using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Xml.Serialization;

using MyLibarySer;
[Serializable]
public class Players
{
    public string Lastname { get; set; }
    public string Club { get; set; }
    public double Result1 { get; set; }
    public double Result2 { get; set; }
    public double Summ { get; set; }
    public bool IsDisqualified { get; set; }

    public Players()
    {
    }

    public Players(string ln, string _club, double res1, double res2)
    {
        Lastname = ln;
        Club = _club;
        Result1 = res1;
        Result2 = res2;
        Summ = res1 + res2;
        IsDisqualified = false;
    }

    public void PrintTable()
    {
        if (!IsDisqualified)
            Console.WriteLine($"{Lastname,-9} {Club,-12} {Summ,-5}");
        else
            Console.WriteLine($"Участник {Lastname} дисквалифицирован");
    }

    public void Disqual()
    {
        if (Summ < 14.0)
        {
            IsDisqualified = true;
        }
    }
}




class Program
{
    private static void SortArray(Players[] players)
    {
        for (int i = 0; i < players.Length; i++)
        {
            for (int j = 0; j < players.Length - i - 1; j++)
            {
                if (players[j].Summ < players[j + 1].Summ)
                {
                    Players temp = players[j];
                    players[j] = players[j + 1];
                    players[j + 1] = temp;
                }
            }
        }
    }
    static void Main()
    {
        Players[] players = {
            new Players("Иванов", "Клуб1", 7.2, 7.4),
            new Players("Петров", "Клуб2", 7.8, 7.5),
            new Players("Сидоров", "Клуб3", 7.5, 7.3),
            new Players("Евелькин", "Клуб52", 6.9, 6.0),
            new Players("Носыч", "Спартак", 7.0, 9.1)
        };

        foreach (var player in players)
        {
            player.Disqual();
        }

        SortArray(players);
        Console.WriteLine("Фамилия   Общество    Сумма");
        foreach (var player in players)
        {
            player.PrintTable();
        }

        string folderPath = "C:\\Users\\novik\\OneDrive\\Рабочий стол\\ser";
        string JSONPath = Path.Combine(folderPath, "Players.json");
        string XMLPath = Path.Combine(folderPath, "Players.xml");
        string BinaryPath = Path.Combine(folderPath, "Players.bin");

        DataSerialazer.SerializeToJSON(players, JSONPath);
        Players[] playerFromJSON = DataSerialazer.DeserializeFromJSON<Players[]>(JSONPath);
        foreach (Players player in playerFromJSON)
        {
            player.PrintTable();
        }
        Console.WriteLine();

        DataSerialazer.SerializeToXML(players, XMLPath);
        Players[] playerFromXML = DataSerialazer.DeserializeFromXML<Players[]>(XMLPath);
        foreach (Players player in playerFromXML)
        {
            player.PrintTable();
        }
        Console.WriteLine();

        DataSerialazer.SerializeToBinary(players, BinaryPath);
        Players[] playerFromBinary = DataSerialazer.DeserializeFromBinary<Players[]>(BinaryPath);
        foreach (Players player in playerFromBinary)
        {
            player.PrintTable();
        }
        Console.WriteLine();
    }

}