﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IIIProjects.Serializers
{
    public abstract class UniversalSerializer
    {
        public abstract void Serialize(object @object, string fileName, string filePath = "");
        public abstract T? Deserialize<T>(string fileName, string filePath);
    }
}
