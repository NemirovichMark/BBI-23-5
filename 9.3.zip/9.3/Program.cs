﻿// 3 номер

/*
Соревнования по футболу между командами проводятся в два этапа. Для 
проведения первого этапа участники разбиваются на две группы по 12 команд. 
Для проведения второго этапа выбирается 6 лучших команд каждой группы по 
результатам первого этапа. Составить список команд участников второго этапа.
2.	Создать класс «Футбольная команда» с 2 классами-наследниками: 
«Женская футбольная команда» и «Мужская футбольная команда». 
Провести среди них отдельные соревнования, но вывести в общей таблице 
по 6 лучших женских и мужских команд, отсортированных по общему количеству баллов 
с указанием пола (т.е.: 1. ЦСКА женская команда 13 баллов; 2 Динамо мужская команда 12 баллов; 
3 Спартак мужская команда 10 баллов…). Использовать динамическую связку: преобразование классов.
*/

using _9._3;
using System.IO;
using System.Xml.Serialization;

[XmlInclude(typeof(MTeam))]
[XmlInclude(typeof(Fteam))]
[XmlInclude(typeof(FootballTeam))]
[Serializable]
public class FootballTeam
{

    protected string name;
    protected string _s;
    protected int _wins;
    protected int _loses;
    public int wins => _wins;

    [XmlAttribute]
    public string Name
    {
        get => name; set => name = value;
    }
    [XmlAttribute]
    public string S
    {
        get => _s; set => _s = value;
    }
    [XmlAttribute]
    public int Wins
    {
        get => _wins; set => _wins = value;
    }
    [XmlAttribute]
    public int Loses
    {
        get => _loses; set => _loses = value;
    }

    public FootballTeam() { }
    public FootballTeam(string names, string s, int q, int e)
    {
        name = names; _s = s; _wins = q; _loses = e;
    }

    public void Print()
    {
        Console.WriteLine("Название команды    {0}\t {1}\t  Победы {2:f2}",
            name, _s, _wins);
    }

    public void Sort(FootballTeam[] a)
    {

        for (int i = 0; i < a.Length - 1; i++)
        {
            double amax = a[i].wins;
            int imax = i;
            for (int j = i + 1; j < a.Length; j++)
            {
                if (a[j].wins > amax)
                {
                    amax = a[j].wins;
                    imax = j;
                }
            }
            FootballTeam temp;
            temp = a[imax];
            a[imax] = a[i];
            a[i] = temp;
        }
    }


}

[Serializable]
public class Fteam : FootballTeam
{
    public Fteam() { }
    public Fteam(string n, string h, int y, int x) : base(n, h, y, x) { }
   

}

[Serializable]
public class MTeam : FootballTeam
{
    public MTeam() { }
    public MTeam(string t, string w, int r, int e) : base(t, w, r, e) { }
    

}
[Serializable]
internal class Program
{
    static void Main(string[] args)

    {  
        
        Fteam[] d = new Fteam[]
        {
        new Fteam("Панды", "женская команда", 7, 5),
        new Fteam("Звёзды", "женская команда", 8, 4),
        new Fteam("Ягуары", "женская команда", 2, 10),
        new Fteam("Молния", "женская команда", 3, 9),
        new Fteam("Волки", "женская команда", 3, 9),
        new Fteam("Тигры", "женская команда", 7, 5),
        new Fteam("Ястребы", "женская команда", 5, 7),
        new Fteam("Драконы", "женская команда", 4, 8),
        new Fteam("Друзья", "женская команда", 6, 6),
        new Fteam("Медведи", "женская команда", 5, 7),
        new Fteam("Орлы", "женская команда", 7, 5),
        new Fteam("Котики", "женская команда", 8, 4)

        };
        

        MTeam[] m = new MTeam[]
        {
        new MTeam("Львы", "мужская команда", 6, 6),
        new MTeam("Смельчаки","мужская команда", 4, 8),
        new MTeam("Ветер", "мужская команда", 7, 5),
        new MTeam("Лисы", "мужская команда", 2, 10),
        new MTeam("Банда","мужская команда", 5, 7),
        new MTeam("Ночь", "мужская команда", 8, 4),
        new MTeam("Воля", "мужская команда", 6, 6),
        new MTeam("Сокол", "мужская команда", 9, 3),
        new MTeam("Стужа","мужская команда", 8, 4),
        new MTeam("Шторм", "мужская команда", 10, 2),
        new MTeam("Комета", "мужская команда", 7, 5),
        new MTeam("Феникс", "мужская команда", 2, 10)
        };

        foreach (var b in d)
        {
            b.Sort(d);
        }

        foreach (var b in m)
        {
            b.Sort(m);
        }



        FootballTeam[] c = new FootballTeam[12];
        int a, r, f;
        a = r = 0;
        for (f = 0; f < c.Length; f++)
        {
            if (a >= d.Length / 2)
            {
                c[f] = m[r];
                r++;
            }
            else if (r >= m.Length / 2)
            {
                c[f] = d[a];
                a++;
            }
            else
                        if (d[a].wins > m[r].wins)
            {
                c[f] = m[r];
                r++;
            }
            else
            {
                c[f] = d[a];
                a++;
            }
        }


        foreach (var b in c)
        {
            b.Sort(c);
        }


        Console.WriteLine("Список лучших команд");
        Console.WriteLine();

        foreach (var sportsmen in c)
        {

             sportsmen.Print(); 
        }
        Console.WriteLine();

        Serial[] serializers = new Serial[2]
        {
            new JsonManager(),
            new XmlManager()
        };

        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        path = Path.Combine(path, "Sample3");
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string[] files = new string[2]
        {
            "task.json",
            "task.xml"
        };

        for (int i = 0; i < files.Length; i++)
        {
            serializers[i].Write(c, Path.Combine(path, files[i]));
        }

        for (int i = 0; i < files.Length; i++)
        {
            c = serializers[i].Read<FootballTeam>(Path.Combine(path, files[i]));
            foreach (FootballTeam sp1 in c)
            {
                sp1.Print();
            }
        }

    }
}