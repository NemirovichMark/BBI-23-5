﻿using Classes;
using Serializers;

class Program
{
    public static void Main()
    {
        void Check(string path) // метод для удвления файла, если он существует по пути
        {
            if (File.Exists(path)) // существует ли файл по пути?
            {
                File.Delete(path); // удалить файл
            }
        }
        Random r = new Random(); // создание переменной для рандомизации игр
        GameCatalog catalog = new GameCatalog(); // создание каталога игр
        string[] titles = { "А", "Б", "В", "Г", "Д", "Е", "Ё", "Ж", "З", "И", "Й", "К", "Л", "М", "Н" }; // названия игр
        string[] desc = { "boring", "normal", "meh", "x_x", ")_)", "0_0", "...", "X", "B)" }; // описания игр
        string[] sett = { "Dark", "magic", "Tears", "Glass", "Ice", "Party", "Deads" }; // сеттинг для игр для вечеринок
        string[] card = { "R", "B", "W" }; // тип карт
        BoardGame[] games = new BoardGame[30]; // массив из 30 игр
        int k = 0; // счётчик
        while (k < 30) // создадим 30 игр для массива games
        {
            int rr = r.Next(1, 3); // определяем тип игры, которая будет добавлена
            switch (rr)
            {
                case 1:
                    games[k] = new CardGame(titles[r.Next(0, titles.Length-1)], r.Next(0, 4), r.Next(4, 8), r.Next(0, 18), desc[r.Next(0, desc.Length - 1)], card[r.Next(0, card.Length - 1)], r.Next(10, 30)); // добавление карточной игры с рандомными полями
                    break;
                case 2:
                    games[k] = new StrategyGame(titles[r.Next(0, titles.Length - 1)], r.Next(0, 4), r.Next(4, 8), r.Next(0, 18), desc[r.Next(0, desc.Length - 1)], r.Next(0, 1), r.Next(20, 120)); // добавление стратегической игры с рандомными полями
                    break;
                case 3:
                    games[k] = new PartyGame(titles[r.Next(0, titles.Length - 1)], r.Next(0, 4), r.Next(4, 8), r.Next(0, 18), desc[r.Next(0, desc.Length - 1)], r.Next(0, 1), sett[r.Next(0, sett.Length - 1)]); // добавление игры для вечеринок с рандомными полями
                    break;
                default:
                    break;
                
            }
            k++;
        }
        for (int i = 0; i < 10; i++) // добавляем первые 10 игр в каталог
        {
            catalog.AddGame(games[i]);
        }
        MyJsonSerializer Json = new MyJsonSerializer(); // создаём сериализаторы json и xml
        MyXmlSerializer Xml = new MyXmlSerializer();
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop); // получаем путь к рабочему столу
        string folderName = "Packs"; // название папки для файлов
        path = Path.Combine(path, folderName); // объединяем путь к рабочему столу и к папке
        if (!Directory.Exists(path)) // проверяем, существует ли уже такая папка
        {
            Directory.CreateDirectory(path); // если нет, то создаём её
        }
        string fileName1 = Path.Combine(path, "raw_data.json"); // создаём путь к файлу в заданную папку
        Check(fileName1); // проверяем наличие файла
        Json.Write<GameCatalog>(catalog, fileName1); // записываем каталог игр в файл
        string fileName2 = Path.Combine(path, "raw_data.xml"); // создаём путь к файлу в заданную папку
        Check(fileName2); // проверяем наличие файла
        Xml.Write<GameCatalog>(catalog, fileName2); // записываем каталог игр в файл
        for (int i = 10; i < 20; i++) // берём индексы с 10 по 19
        {
            catalog.AddGame(games[i]); // добавляем второй десяток игр из games
        }
        catalog.AddGame(new CardGame(titles[r.Next(0, titles.Length - 1)], r.Next(0, 4), r.Next(4, 8), r.Next(0, 18), desc[r.Next(0, desc.Length - 1)], card[r.Next(0, card.Length - 1)], r.Next(10, 30))); // добавляем карточную игру с рандомными полями
        string fileName3 = Path.Combine(path, "data.json"); // создаём путь к файлу в заданную папку
        Check(fileName3); // проверяем наличие файла
        Json.Write<GameCatalog>(catalog, fileName3); // записываем каталог игр в файл
        for (int i = 0;i < 5;i++) { catalog.RemoveGame(); } // удаляем первые 5 игр в списке
        catalog.RemoveGame(6); // удаляем 6-ю по индексу(7-ю по счёту) игру
        string fileName4 = Path.Combine(path, "data.xml"); // создаём путь к файлу в заданную папку
        Check(fileName4); // проверяем наличие файла
        Xml.Write<GameCatalog>(catalog, fileName4); // записываем каталог игр в файл
        catalog.DisplayCatalog(); // выводим каталог на консоль
        GameCatalog data1 = Json.Read<GameCatalog>(fileName1); // считываем каталог из файла в переменную
        Console.Write("\n\n\n");
        Console.WriteLine("raw_data.json"); // обозначаем файл
        data1.DisplayCatalog(); // выводим каталог на консоль
        GameCatalog data2 = Xml.Read<GameCatalog>(fileName2); // считываем каталог из файла в переменную
        data2.DisplayCatalog(); // выводим каталог на консоль
        Console.Write("\n\n\n");
        Console.WriteLine("raw_data.xml"); // обозначаем файл
        GameCatalog data3 = Json.Read<GameCatalog>(fileName3); // считываем каталог из файла в переменную
        Console.Write("\n\n\n");
        Console.WriteLine("data.json"); // обозначаем файл
        data3.DisplayCatalog(); // выводим каталог на консоль
        GameCatalog data4 = Xml.Read<GameCatalog>(fileName4); // считываем каталог из файла в переменную
        Console.Write("\n\n\n");
        Console.WriteLine("data.xml"); // обозначаем файл
        data4.DisplayCatalog(); // выводим каталог на консоль
        MyBinSerializer Bin = new MyBinSerializer();
        for (int i = 20; i < 30; i++) // берём индексы с 20 по 29
        {
            catalog.AddGame(games[i]); // добавляем второй десяток игр из games
        }
        string fileName5 = Path.Combine(path, "raw_data.bin"); // создаём путь к файлу в заданную папку
        Check(fileName5); // проверяем наличие файла
        Bin.Write<GameCatalog>(catalog, fileName5); // записываем каталог игр в файл
        catalog.Sort(); // сортируем каталог
        string fileName6 = Path.Combine(path, "sorted_data.bin"); // создаём путь к файлу в заданную папку
        Check(fileName6); // проверяем наличие файла
        Bin.Write<GameCatalog>(catalog, fileName6); // записываем каталог игр в файл
        CardGame o = new CardGame(); // создаём карточную игр, чтобы получить из неё тип класса
        IEnumerable<BoardGame> cards = catalog.Filter(o.GetType()); // создаём список с карточными играми из каталога
        GameCatalog c = new GameCatalog(); // создаём новый каталог
        foreach (BoardGame board in cards) { c.AddGame(board); } // добавляем игры из списка карточных игр в новый каталог
        Console.Write("\n\n\n");
        Console.WriteLine($"Среднее мин кол-во игроков: {c.AverageMinPlayers}; макс: {c.AverageMaxPlayers}; разброс игроков: {c.MeanPlayerRange}; средний возраст: {c.MeanAgeRestriction}"); // выводим информацию из аналитика на консоль
        for (int i = 0; i < catalog.Games.Count; i++) { catalog.RemoveGame(); } // удаляем игры из первого каталога
        for (int i = 0; i < c.Games.Count; i++) { c.RemoveGame(); } // удаляем игры из второго каталога
        GameCatalog data5 = Bin.Read<GameCatalog>(fileName5); // считываем каталог из файла в переменную
        Console.Write("\n\n\n");
        Console.WriteLine("raw_data.bin"); // обозначаем файл
        data5.DisplayCatalog(); // выводим каталог на консоль
        GameCatalog data6 = Bin.Read<GameCatalog>(fileName6); // считываем каталог из файла в переменную
        Console.Write("\n\n\n");
        Console.WriteLine("sorted_data.bin"); // обозначаем файл
        data6.DisplayCatalog(); // выводим каталог на консоль
        Console.ReadKey();
    }
}