﻿namespace Classes
{
    public partial class GameCatalog // часть класса катлог игр
    {
        public BoardGame[] Filter( Type gameType) // метод для выбора игр по типу
        {
            List<BoardGame> filteredGames = new List<BoardGame>();
            foreach (var game in games)
            {
                if (game.GetType() == gameType)
                {
                    filteredGames.Add(game);
                }
            }
            return filteredGames.ToArray();
        }
    }
}
