﻿using System.Text.Json;
using System.Xml.Serialization;
using ProtoBuf;
using Classes;
namespace Serializers
{
    public abstract class MySerializer // базовый класс для сериализаторов
    {
        public abstract void Write<T>(T obj, string filePath);
        public abstract T Read<T>(string filePath);
    }
    public class MyJsonSerializer : MySerializer // сериализатор json
    {
        public override void Write<T>(T obj, string filePath) // метод для записи объекта obj типа T в файл по пути filePath
        {
            using (FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate)) // подключение к пути
            {
                JsonSerializer.Serialize(fs, obj); // запись
            }
        }
        public override T Read<T>(string filePath) // метод для чтения по пути filePath и возвращение объекта типа T
        {
            using (FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate)) // подключение к пути
            {
                return JsonSerializer.Deserialize<T>(fs); // чтение
            }
        }
    }
    public class MyXmlSerializer : MySerializer
    {
        public override void Write<T>(T obj, string filePath)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate))
            {
                new XmlSerializer(typeof(T)).Serialize(fs, obj);
            }
        }
        public override T Read<T>(string filePath)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate))
            {
                return (T)new XmlSerializer(typeof(T)).Deserialize(fs);
            }
        }
    }
    public class MyBinSerializer : MySerializer
    {
        public override void Write<T>(T obj, string filePath)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate))
            {
                Serializer.Serialize(fs, obj);
            }
        }
        public override T Read<T>(string filePath)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate))
            {
                return Serializer.Deserialize<T>(fs);
            }
        }
    }
}