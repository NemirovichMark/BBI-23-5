﻿using Interfaces;
namespace Classes
{
    public partial class GameCatalog : IAnalyzer // часть класса каталог игр, реализующая интерфейс аналитик
    {
        public double AverageMinPlayers(BoardGame[] games) // среднее значение минимума игроков
        {

            double sum = 0;
            int count = 0;
            foreach (var game in games)
            {
                sum += game.MinimumPlayers;
                count++;
            }
            return count > 0 ? sum / count : 0;

        }

        public double AverageMaxPlayers(BoardGame[] games) // среднее значение максимума игроков
        {

            double sum = 0;
            int count = 0;
            foreach (var game in games)
            {
                sum += game.MaximumPlayers;
                count++;
            }
            return count > 0 ? sum / count : 0;

        }

        public double MeanPlayerRange(BoardGame[] games) // среднее значение разности допустимого количества игроков (max - min)
        {

            double sum = 0;
            int count = 0;
            foreach (var game in games)
            {
                sum += game.MaximumPlayers - game.MinimumPlayers;
                count++;
            }
            return count > 0 ? sum / count : 0;

        }

        public double MeanAgeRestriction(BoardGame[] games) // среднее значение ограничения по возрасту
        {

            double sum = 0;
            int count = 0;
            foreach (var game in games)
            {
                sum += game.AgeRestriction;
                count++;
            }
            return count > 0 ? sum / count : 0;

        }
    }
}
