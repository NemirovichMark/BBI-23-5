﻿namespace Classes
{
    public partial class GameCatalog // часть класса каталог игр
    {
        public void Sort() // сортировка шелла
        {
            
            int n = games.Count;
            int gap = n / 2;
            while (gap > 0)
            {
                for (int i = gap; i < n; i++)
                {
                    BoardGame temp = games[i];
                    int j;
                    for (j = i; j >= gap && games[j - gap] > temp; j -= gap)
                    {
                        games[j] = games[j - gap];
                    }
                    games[j] = temp;
                }
                gap /= 2;
            }
    
        }
    }
}