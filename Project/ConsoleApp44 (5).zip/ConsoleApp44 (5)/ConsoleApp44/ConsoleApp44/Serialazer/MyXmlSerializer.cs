﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ConsoleApp44.Serialazer
{
    public class MyXmlSerializer : MySerializer
    {
        public override void Serializing<T>(T obj, string fileName)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));

            using (FileStream fs = new FileStream(fileName + ".xml", FileMode.OpenOrCreate))
            {
                serializer.Serialize(fs, obj);
            }
        }

        public override dynamic Deserializing<T>(string fileName)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));

            using (FileStream fs = new FileStream(fileName + ".xml", FileMode.OpenOrCreate))
            {
                return (dynamic)new XmlSerializer(typeof(T)).Deserialize(fs);
            }
        }

    }
}
