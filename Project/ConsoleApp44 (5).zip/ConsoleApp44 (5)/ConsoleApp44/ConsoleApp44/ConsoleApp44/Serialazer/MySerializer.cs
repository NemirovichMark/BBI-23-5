﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ConsoleApp44
{
    public abstract class MySerializer
    {
        public abstract void Serializing<T>(T obj, string fileName); 

       public abstract dynamic Deserializing<T>(string fileName);
       
    }
}
