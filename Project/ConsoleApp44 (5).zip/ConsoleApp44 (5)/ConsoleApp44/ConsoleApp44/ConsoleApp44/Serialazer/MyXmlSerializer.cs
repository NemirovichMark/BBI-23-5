﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ConsoleApp44.Serialazer
{
    public class MyXmlSerializer : MySerializer
    {
        public override void Serializing<T>(T obj, string fileName)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));

            using (TextWriter writer = new StreamWriter(fileName + ".xml"))
            {
                serializer.Serialize(writer, obj);
            }
        }

        //public override dynamic Deserializing(string fileName)
        //{
        //    XmlSerializer serializer = new XmlSerializer(typeof(object));

        //    using (TextReader reader = new StreamReader(fileName + ".xml"))
        //    {
        //        return (dynamic)serializer.Deserialize(reader);
        //    }
        //}

        public override dynamic Deserializing<T>(string fileName)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));

            using (TextReader reader = new StreamReader(fileName + ".xml"))
            {
                return (dynamic)serializer.Deserialize(reader);
            }
        }
    }
}
