﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ConsoleApp44.Serialazer
{
    

    public class MyJsonSerializer : MySerializer
    {
        public override void Serializing<T>(T obj, string fileName)
        {
            string json = JsonSerializer.Serialize(obj);
            File.WriteAllText(fileName + ".json", json);
        }

        public override dynamic Deserializing<T>(string fileName)
        {
            string json = File.ReadAllText(fileName + ".json");
            return JsonSerializer.Deserialize<dynamic>(json);
        }
    }
}
