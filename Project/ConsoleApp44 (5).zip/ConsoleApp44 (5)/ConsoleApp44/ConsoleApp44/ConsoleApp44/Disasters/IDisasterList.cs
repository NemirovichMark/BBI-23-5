﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp44
{
    internal interface IDisasterList
    {
        void AddDisaster(NaturalDisaster disaster);
        void AddDisasters(NaturalDisaster[] disasters);
        void RemoveDisaster(NaturalDisaster disaster);
        void RemoveDisasters(NaturalDisaster[] disasters);
        void DisplayList();
    }
}
