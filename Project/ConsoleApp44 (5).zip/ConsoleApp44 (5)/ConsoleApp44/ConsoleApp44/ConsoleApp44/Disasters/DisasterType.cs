﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ConsoleApp44
{
    [Serializable]
    public abstract class DisasterType
    {
        
        private string name;
        private string description;
        private int danger;


        public string Name { get; protected set; }
        public string Description { get; protected set; }
        public int Danger { get; protected set; }

        [JsonConstructor]
        public DisasterType() 
        {
            
        }
        public DisasterType(string name, string description, int danger)
        {
            Name = name;
            Description = description;
            Danger = danger;
        }

        public override string ToString()
        {
            return $": {Name}, Description: {Description}, Danger: {Danger}";
        }
    }

    public class Earthquake : DisasterType
    {
        public Earthquake() :  base()
        {
        }

        public Earthquake(string name, string description, int danger) : base(name, description, danger)
        {
        }
    }

    public class Hurricane : DisasterType
    {
        public Hurricane() : base()
        {
        }

        public Hurricane(string name, string description, int danger) : base(name, description, danger)
        {
        }
    }

    public class Fire : DisasterType
    {
        public Fire() : base()
        {
        }

        public Fire(string name, string description, int danger) : base(name, description, danger)
        {
        }
    }

    public class Flood : DisasterType
    {
        public Flood() : base()
        {
        }

        public Flood(string name, string description, int danger) : base(name, description, danger)
        {
        }
    }

}
