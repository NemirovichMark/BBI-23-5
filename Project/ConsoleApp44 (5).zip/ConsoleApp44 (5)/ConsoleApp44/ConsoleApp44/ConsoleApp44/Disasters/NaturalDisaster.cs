﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp44
{
    [Serializable]
    public class NaturalDisaster
    {
        protected string name;
        private DisasterType disasterType;
        private string location;
        private int year;
        public string Name { get; protected set; }
        public DisasterType DisasterType { get; protected set; }
        public string Location { get; protected set; }
        public int Year { get; protected set; }


        public NaturalDisaster()
        {
            
        }
        public NaturalDisaster(string name, DisasterType disasterType, string location, int year)
        {
            Name = name;
            DisasterType = disasterType;
            Location = location;
            Year = year;
        }

        public string EstimateHarm(int minRange, int maxRange)
        {
            if (disasterType is Hurricane)
            {
                if (maxRange - maxRange > 5) return "высокий уровнь";
                else return "низкий уровнь";
            }
            else if (disasterType is Earthquake)
            {
                if (maxRange - maxRange > 7) return "высокий уровнь";
                else return "низкий уровнь";
            }
            else if (disasterType is Fire)
            {
                if (maxRange - maxRange > 4) return "высокий уровнь";
                else return "низкий уровнь";
            } 
            else if (disasterType is Flood) 
            {
                if (maxRange - maxRange > 8) return "высокий уровнь";
                else return "низкий уровнь";
            }
            return "";
        }


        public override string ToString()
        {
            return $"Name: {Name}, Type: {DisasterType.ToString()}, Location: {Location}, Year: {Year} \n";
        }
    }

}
