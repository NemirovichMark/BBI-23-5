﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ConsoleApp44
{
    public partial class DisasterList : IDisasterList

    {
        private List<NaturalDisaster> disastersList = new List<NaturalDisaster>();

        [JsonConstructor]

        public DisasterList()
        {
            
        }

        public DisasterList(NaturalDisaster naturalDisaster)
        {
            disastersList.Add(naturalDisaster);
        }

        public void AddDisaster(NaturalDisaster disaster)
        {
            disastersList.Add(disaster);
        }

        public void AddDisasters(NaturalDisaster[] disasters)
        {
            disastersList.AddRange(disasters);
        }

        public void RemoveDisaster(NaturalDisaster disaster)
        {
            disastersList.Remove(disaster);
        }

        public void RemoveDisasters(NaturalDisaster[] disasters)
        {
            foreach (var disaster in disasters)
            {
                disastersList.Remove(disaster);
            }
        }

        public List<NaturalDisaster> GetDisastersList()
        {
            return disastersList;
        }

        public NaturalDisaster GetElementFromList(int index) 
        {
            return disastersList.ElementAt(index);
        }
        public void DisplayList()
        {
            foreach (var disaster in disastersList)
            {
                Console.WriteLine(disaster.ToString());
            }
        }
    }

    public partial class DisasterList
    {
        private List<string> disasters;
        private int decade;

        public DisasterList(int decade)
        {
            this.decade = decade;
            disasters = new List<string>();
        }

       

       
    }


    public partial class DisasterList
    {
        public void SortByDamageDescending()
        {
            disasters.Sort();
            disasters.Reverse();
        }

        public void SortByYearAscending()
        {
            disasters.Sort();
        }
    }

}
