﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ConsoleApp44
{
    [Serializable]
    [XmlInclude(typeof(NaturalDisaster))] 
    [ProtoContract]
    [ProtoInclude(1, typeof(NaturalDisaster))]
   
    public class NaturalDisaster
    {
        private string name;
        private DisasterType disasterType;
        private string location;
        private int year;

        [ProtoMember(2)]
        public string Name
        {
            get { return name; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Название не может быть пустым");
                }
                name = value;
            }
        }

        [ProtoMember(3)]
        public DisasterType DisasterType
        {
            get { return disasterType; }
            set { disasterType = value; }
        }

        [ProtoMember(4)]
        public string Location
        {
            get { return location; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Локация не может быть пустой");
                }
                location = value;
            }
        }

        [ProtoMember(5)]
        public int Year
        {
            get { return year; }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Год должен быть положительным числом");
                }
                year = value;
            }
        }


        public NaturalDisaster()
        {
            
        }
        public NaturalDisaster(string name, DisasterType disasterType, string location, int year)
        {
            Name = name;
            DisasterType = disasterType;
            Location = location;
            Year = year;
        }

        public int EstimateHarm(int minRange, int maxRange)
        {
            if (disasterType is Hurricane)
            {
                if (maxRange - minRange > 5) return 6;
                else return 3;
            }
            else if (disasterType is Earthquake)
            {
                if (maxRange - minRange > 7) return 9;
                else return 4;
            }
            else if (disasterType is Fire)
            {
                if (maxRange - minRange > 4) return 8;
                else return 6;
            } 
            else if (disasterType is Flood) 
            {
                if (maxRange - minRange > 8) return 7;
                else return 5;
            }
            return 0;
        }


        public override string ToString()
        {
            return $"Name: {Name}, Type: {DisasterType.ToString()}, Damage: {EstimateHarm(0, DisasterType.Danger)} Location: {Location}, Year: {Year} \n";
        }
    }

}
