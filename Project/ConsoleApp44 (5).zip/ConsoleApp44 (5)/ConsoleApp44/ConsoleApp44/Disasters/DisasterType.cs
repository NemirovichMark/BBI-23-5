﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ConsoleApp44
{
    [Serializable]
    [XmlInclude(typeof(DisasterType)), XmlInclude(typeof(Earthquake))]
    [XmlInclude(typeof(DisasterType)), XmlInclude(typeof(Hurricane))]
    [XmlInclude(typeof(DisasterType)), XmlInclude(typeof(Fire))]
    [XmlInclude(typeof(DisasterType)), XmlInclude(typeof(Flood))]

    [ProtoContract]
    [ProtoInclude(1, typeof(Earthquake))]
    [ProtoInclude(2, typeof(Hurricane))]
    [ProtoInclude(3, typeof(Flood))]
    [ProtoInclude(4, typeof(Fire))]

    public abstract class DisasterType
    {
        
        private string name;
        private string description;
        private int danger;

        [ProtoMember(13)]
        public string Name
        {
            get { return name; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Название не должно быть пустым");
                }

                name = value;
            }
        }

        [ProtoMember(14)]

        public string Description
        {
            get { return description; }
             set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Описание не должно быть пустым");
                }

                description = value;
            }
        }

        [ProtoMember(15)]
        public int Danger
        {
            get { return danger; }
             set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Уровень опаснсности не должен быть отрицательным");
                }

                danger = value;
            }
        }
        [JsonConstructor]
        public DisasterType() 
        {
            
        }
        public DisasterType(string name, string description, int danger)
        {
            Name = name;
            Description = description;
            Danger = danger;
        }

        public override string ToString()
        {
            return $": {Name}, Description: {Description}, Danger: {Danger}";
        }
    }

    public class Earthquake : DisasterType
    {
        public Earthquake() 
        {
        }

        public Earthquake(string name, string description, int danger) : base(name, description, danger)
        {
        }
    }

    public class Hurricane : DisasterType
    {
        public Hurricane() 
        {
        }

        public Hurricane(string name, string description, int danger) : base(name, description, danger)
        {
        }
    }

    public class Fire : DisasterType
    {
        public Fire() 
        {
        }

        public Fire(string name, string description, int danger) : base(name, description, danger)
        {
        }
    }

    public class Flood : DisasterType
    {
        public Flood() 
        {
        }

        public Flood(string name, string description, int danger) : base(name, description, danger)
        {
        }
    }

}
