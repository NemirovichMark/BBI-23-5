﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace ConsoleApp44
{
    [Serializable]
    [XmlInclude(typeof(DisasterList))]

    [ProtoContract]
    [ProtoInclude(1, typeof(DisasterList))]
   
    public partial class DisasterList : IDisasterList

    {
        private List<NaturalDisaster> disastersList = new List<NaturalDisaster>();

        [JsonConstructor]

        public DisasterList()
        {
            
        }

        [ProtoMember(2)]


        public List<NaturalDisaster> DisastersList
        {
          
            get { return disastersList; }
            set
            {
               disastersList.AddRange(value);
            }
        }
    
        public DisasterList(NaturalDisaster naturalDisaster)
        {
            disastersList.Add(naturalDisaster);
        }

        public void AddDisaster(NaturalDisaster disaster)
        {
            disastersList.Add(disaster);
        }

        public void AddDisaster(NaturalDisaster[] naturalDisasters)
        {
            disastersList.AddRange(naturalDisasters);
        }

        public void RemoveDisaster(NaturalDisaster disaster)
        {
            disastersList.Remove(disaster);
        }

        public void RemoveDisaster(DisasterList disasters)
        {
            DisasterList newDisasters = new DisasterList();

            foreach (NaturalDisaster disaster in disasters.GetDisastersList())
            {
               newDisasters.AddDisaster(disaster);
            }
            disasters = newDisasters;
        }

        public List<NaturalDisaster> GetDisastersList()
        {
            return disastersList;
        }

        public NaturalDisaster GetElementFromList(int index) 
        {
            return disastersList.ElementAt(index);
        }
        public void DisplayList()
        {
            foreach (var disaster in disastersList)
            {
                Console.WriteLine(disaster.ToString());
            }
        }
    }
    [XmlInclude(typeof(DisasterList))]

    
    [ProtoInclude(3, typeof(DisasterList))]
    public partial class DisasterList
    {
        private int decade;

       

        public DisasterList(int decade)
        {
            this.decade = decade;
            disastersList = new List<NaturalDisaster>();
        }

        [ProtoMember(4)]
        public int Decade
        {
            get { return decade; }
            set { decade = value; }
        }
        public void AddDisaster(NaturalDisaster disaster, int decade)
        {
            if (disaster.Year > decade && disaster.Year < decade + 9)
            {
                disastersList.Add(disaster);
            }
        }

        public void RemoveDisaster(int decade)
        {
           DisasterList list = new DisasterList();
            foreach (NaturalDisaster data in disastersList)
            {
                if (data.Year > decade && data.Year < decade + 9)
                {
                    list.AddDisaster(data);
                }

            }
            disastersList = list.GetDisastersList();
           
        }
    }
    public partial class DisasterList
    {
        public void SortingByYear() 
        {
            for (int i = 0; i < disastersList.Count; i++)
            {
                for (int j = i + 1; j < disastersList.Count; j++)
                {
                    if (disastersList[i].Year > disastersList[j].Year)
                    {
                        var temp = disastersList[i];
                        disastersList[i] = disastersList[j];
                        disastersList[j] = temp;
                    }
                }
            }

        }

        public void SortingByDamage()
        {
            for (int i = 0; i < disastersList.Count; i++)
            {
                for (int j = i + 1; j < disastersList.Count; j++)
                {
                    if (disastersList[i].EstimateHarm(0, disastersList[i].DisasterType.Danger) > disastersList[j].EstimateHarm(0,disastersList[i].DisasterType.Danger))
                    {
                        var temp = disastersList[i];
                        disastersList[i] = disastersList[j];
                        disastersList[j] = temp;
                    }
                }
            }
            disastersList.Reverse();
        }
    }
}
