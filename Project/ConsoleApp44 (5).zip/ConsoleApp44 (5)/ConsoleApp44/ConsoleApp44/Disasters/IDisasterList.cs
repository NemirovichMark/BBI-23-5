﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp44
{
    internal interface IDisasterList
    {
        void AddDisaster(NaturalDisaster disaster);
        void AddDisaster(NaturalDisaster[] naturalDisasters);
        void RemoveDisaster(NaturalDisaster disaster);
        void RemoveDisaster(DisasterList disasters);
        void DisplayList();
    }
}
