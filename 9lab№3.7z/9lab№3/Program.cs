﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProtoBuf;
using System.Text.Json;
using System.Xml.Serialization;

[ProtoContract]
abstract class Sportsman
{
    [ProtoMember(1)]
    public string Name { get; set; }
    [ProtoMember(2)]
    public int Result { get; set; }

    protected Sportsman() { } // Parameterless constructor needed for serialization.

    public Sportsman(string name, int result)
    {
        Name = name;
        Result = result;
    }

    public abstract void Display();
}

class SkierGirl : Sportsman
{
    public SkierGirl(string name, int result) : base(name, result) { }

    public override void Display()
    {
        Console.WriteLine($"Гонщица {Name} заняла {Result} место");
    }
}

class SkierBoy : Sportsman
{
    public SkierBoy(string name, int result) : base(name, result) { }

    public override void Display()
    {
        Console.WriteLine($"Гонщик {Name} занял {Result} место");
    }
}

class Serializer<T>
{
    public void Serialize(string filePath, T data)
    {
        using (var file = File.Create(filePath))
        {
            Serializer.Serialize(file, data);
        }
    }

    public T Deserialize(string filePath)
    {
        using (var file = File.OpenRead(filePath))
        {
            return Serializer.Deserialize<T>(file);
        }
    }
}

class JsonSerializer<T> : Serializer<T>
{
    public void Serialize(string filePath, T data)
    {
        string jsonData = JsonSerializer.Serialize(data);
        File.WriteAllText(filePath, jsonData);
    }

    public T Deserialize(string filePath)
    {
        string jsonData = File.ReadAllText(filePath);
        return JsonSerializer.Deserialize<T>(jsonData);
    }
}

class XmlSerializer<T> : Serializer<T>
{
    public void Serialize(string filePath, T data)
    {
        var serializer = new System.Xml.Serialization.XmlSerializer(typeof(T));
        using (var stream = new FileStream(filePath, FileMode.Create))
        {
            serializer.Serialize(stream, data);
        }
    }

    public T Deserialize(string filePath)
    {
        var serializer = new System.Xml.Serialization.XmlSerializer(typeof(T));
        using (var stream = new FileStream(filePath, FileMode.Open))
        {
            return (T)serializer.Deserialize(stream);
        }
    }
}

class BinarySerializer<T> : Serializer<T>
{
    public void Serialize(string filePath, T data)
    {
        using (var file = File.Create(filePath))
        {
            Serializer.Serialize(file, data);
        }
    }

    public T Deserialize(string filePath)
    {
        using (var file = File.OpenRead(filePath))
        {
            return Serializer.Deserialize<T>(file);
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        List<Sportsman> skierGirlsGroup1 = new List<Sportsman>
        {
            new SkierGirl("Анна", 2),
            new SkierGirl("Мария", 1),
            new SkierGirl("Елена", 3)
        };

        List<Sportsman> skierGirlsGroup2 = new List<Sportsman>
        {
            new SkierGirl("Ольга", 1),
            new SkierGirl("Ирина", 2),
            new SkierGirl("Татьяна", 3)
        };

        List<Sportsman> skierBoysGroup1 = new List<Sportsman>
        {
            new SkierBoy("Сергей", 3),
            new SkierBoy("Иван", 2),
            new SkierBoy("Петр", 1)
        };

        List<Sportsman> skierBoysGroup2 = new List<Sportsman>
        {
            new SkierBoy("Алексей", 1),
            new SkierBoy("Дмитрий", 2),
            new SkierBoy("Николай", 3)
        };

        List<Sportsman> allParticipants = new List<Sportsman>();
        allParticipants.AddRange(skierGirlsGroup1);
        allParticipants.AddRange(skierGirlsGroup2);
        allParticipants.AddRange(skierBoysGroup1);
        allParticipants.AddRange(skierBoysGroup2);

        // Create serializer instances
        var jsonSerializer = new JsonSerializer<List<Sportsman>>();
        var xmlSerializer = new XmlSerializer<List<Sportsman>>();
        var binarySerializer = new BinarySerializer<List<Sportsman>>();

        // Serialize to JSON, XML, and Binary formats
        jsonSerializer.Serialize(@"SerializedData\Skiers.json", allParticipants);
        xmlSerializer.Serialize(@"SerializedData\Skiers.xml", allParticipants);
        binarySerializer.Serialize(@"SerializedData\Skiers.bin", allParticipants);

        // Deserialize from JSON, XML, and Binary formats
        var deserializedJson = jsonSerializer.Deserialize(@"SerializedData\Skiers.json");
        var deserializedXml = xmlSerializer.Deserialize(@"SerializedData\Skiers.xml");
        var deserializedBinary = binarySerializer.Deserialize(@"SerializedData\Skiers.bin");

        // Print deserialized data
        Console.WriteLine("Deserialized Data from JSON:");
        PrintParticipants(deserializedJson);
        Console.WriteLine("\nDeserialized Data from XML:");
        PrintParticipants(deserializedXml);
        Console.WriteLine("\nDeserialized Data from Binary:");
        PrintParticipants(deserializedBinary);
    }

    static void PrintParticipants(List<Sportsman> participants)
    {
        foreach (var participant in participants)
        {
            participant.Display();
        }
    }
}
