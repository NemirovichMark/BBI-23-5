﻿using System;
using System.IO;
using System.Text.Json.Serialization;
//using System.Collections;
using System.Xml.Serialization;
//using Newtonsoft.Json;
using ProtoBuf;



[ProtoBuf.ProtoContract()]
[ProtoBuf.ProtoInclude(1, typeof(Cross100))]
[ProtoBuf.ProtoInclude(2, typeof(Cross500))]
[XmlInclude(typeof(Sportsmen))]
[XmlInclude(typeof(Cross100))]
[XmlInclude(typeof(Cross500))]
[Serializable]
    abstract public class Sportsmen
{
    [XmlAttribute]
        [ProtoMember(3)]
        public string _famile { get; set; }
    [XmlAttribute]
    [ProtoMember(4)]
        public string _group { get;  set; }
    [XmlAttribute]
    [ProtoMember(5)]
        public string _famileP { get;  set; }
    [XmlAttribute]
    [ProtoMember(6)]
        public double _time { get; set; }
    [XmlAttribute]
    [ProtoMember(7)]
    public int _norm { get; set; }
        [XmlAttribute]
        [ProtoMember(8)]
        public bool _isNorm { get; set; } = false;
    
        public Sportsmen() { }
    
        [JsonConstructor]

        public Sportsmen(string _Famile, string _Group, string _FamileP, double _Time, int _Norm, bool _IsNorm)
        {
            _famile = _Famile;
            _group = _Group;
            _famileP = _FamileP;
            _time = _Time;
            if (_Time < _Norm)
                _isNorm = true;
            else
                _isNorm = false;
        }
        public void Print()
        {
            Console.Write($"{_famile,-15} {_group,-12} {_famileP,-12}");
            Console.WriteLine("     {0,6:f2}       {1} ", _time, _isNorm);

        }
        public virtual void PrintTitle()
        {
            Console.WriteLine($"{"Фамилия",-15} {"Группа",-12} {"Преподаватель",-12} {"Результат",-12} {"Сдан норм.",-12}");

        }
    }
[ProtoBuf.ProtoContract()]
[Serializable]
    public class Cross500 : Sportsmen
    {
        public const int _Norm = 100;
        public const string _cross = "Кросс 500м";
        public Cross500() { }
        [JsonConstructor]

        public Cross500(string _Famile, string _Group, string _FamileP, double _Time) : base( _Famile,  _Group,  _FamileP,  _Time,  _Norm,  false)
        { }
        public override void PrintTitle()
        {
            Console.WriteLine();
            Console.Write($"{_cross,-15} ");
            Console.WriteLine("Норматив {0:d} c", _Norm);
            Console.WriteLine($"{"Фамилия",-15} {"Группа",-12} {"Преподаватель",-12} {"Результат",-12} {"Сдан норм.",-12}");
        }
    }
[ProtoBuf.ProtoContract()]
[Serializable]
    public class Cross100 : Sportsmen
    {
        public const int _Norm = 18;
        public const string _cross = "Кросс 100м";
        public Cross100() { }
        [JsonConstructor]

        public Cross100(string _Famile, string _Group, string _FamileP, double _Time) : base(_Famile, _Group, _FamileP, _Time, _Norm, false)
        { }
        public override void PrintTitle()
        {
            Console.WriteLine();
            Console.Write($"{_cross,-15} ");
            Console.WriteLine("Норматив {0:d} c", _Norm);
            Console.WriteLine($"{"Фамилия",-15} {"Группа",-12} {"Преподаватель",-12} {"Результат",-12} {"Сдан норм.",-12}");
        }
    }
    internal class Program
    {
        static void Main(string[] args)

        {
         string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop); 
         desktopPath +=  @"\WorkData\";
            if  (! Directory.Exists(desktopPath) )
            {
                Directory.CreateDirectory(desktopPath);
            }
           
            

            Cross100[] cr100 = new Cross100[]
            {
                    new Cross100("Иванова", "ББИ-23-5", "Шмеерзон", 17.3 ),
                    new Cross100("Петрова", "ББИ-23-4", "Лавров", 18.23 ),
                    new Cross100("Сидорова", "ББИ-23-3", "Комзалов", 17.11 ),
                    new Cross100("Ковальчук", "ББИ-23-2", "Зинчук", 17.2),
                    new Cross100("Суворова", "ББИ-23-1", "Сморокин", 18.11)
            };
            Cross500[] cr500 = new Cross500[]
           {
                    new Cross500("Иванова", "ББИ-23-5", "Шмеерзон", 105.3),
                    new Cross500("Петрова", "ББИ-23-4", "Лавров", 99.23),
                    new Cross500("Сидорова", "ББИ-23-3", "Комзалов", 98.11),
                    new Cross500("Ковальчук", "ББИ-23-2", "Зинчук", 101.2),
                    new Cross500("Суворова", "ББИ-23-1", "Сморокин", 99.87)
           };


            toWork(cr100);
            string path100js = Path.Combine(desktopPath, "cr100.json");
            string path100xml = Path.Combine(desktopPath, "cr100.xml");
            string path100bin = Path.Combine(desktopPath, "cr100.bin");
            var jsoner = new JsonSerializerHelper();

            // Сериализация объекта в JSON файл
            jsoner.SerializeTo(cr100, path100js);
            Console.WriteLine($"Записаны данные в {path100js}");

            var biner = new ProtobufSerializerHelper();   // Сериализация объекта в бинарный файл
            biner.SerializeTo(cr100, path100bin);
            Console.WriteLine($"Записаны данные в {path100bin}");

            
            var xmler = new XmlSerializerHelper();       // Сериализация объекта в XML файл
            xmler.SerializeTo(cr100, path100xml);
            Console.WriteLine($"Записаны данные в {path100xml}");
            
            


            toWork(cr500);
            string path500js = Path.Combine(desktopPath, "cr500.json");
            string path500xml = Path.Combine(desktopPath, "cr500.xml");
            string path500bin = Path.Combine(desktopPath, "cr500.bin");

            jsoner.SerializeTo(cr500, path500js);  //Запись в файл
            Console.WriteLine($"Записаны данные в {path500js}");
            biner.SerializeTo(cr500, path500bin);
            Console.WriteLine($"Записаны данные в {path500bin}");
            xmler.SerializeTo(cr500, path500xml);
            Console.WriteLine($"Записаны данные в {path500xml}");


            Cross100[] cr100New = jsoner.DeserializeFrom<Cross100[]>(path100js);
            if (cr100New != null)
            {
                Console.WriteLine($"Считаны данные из {path100js}");
                foreach (Cross100 cr5 in cr100New)
                {
                    Console.WriteLine($"Name: {cr5._famile}, Group: {cr5._group}, Prep {cr5._famileP}, Rez {cr5._time}, Norm {cr5._isNorm} ");
                }
                toWork(cr100New);
            }
            else
            {
                Console.WriteLine("Ошибка десериализации.");
            }

            Cross100[] cr100NewP = biner.DeserializeFrom<Cross100[]>(path100bin);
            if (cr100NewP != null)
            {
                Console.WriteLine($"Считаны данные из {path100bin}");
                foreach (Cross100 cr5 in cr100NewP)
                {
                    Console.WriteLine($"Name: {cr5._famile}, Group: {cr5._group}, Prep {cr5._famileP}, Rez {cr5._time}, Norm {cr5._isNorm} ");
                }
                toWork(cr100NewP);
            }
            else
            {
                Console.WriteLine("Ошибка десериализации.");
            }

        Cross100[] cr100NewX = xmler.DeserializeFrom<Cross100[]>(path100xml);
        if (cr100NewX != null)
        {
            Console.WriteLine($"Считаны данные из {path100xml}");
            foreach (Cross100 cr5 in cr100NewX)
            {
                Console.WriteLine($"Name: {cr5._famile}, Group: {cr5._group}, Prep {cr5._famileP}, Rez {cr5._time}, Norm {cr5._isNorm} ");
            }
            toWork(cr100NewX);
        }
        else
        {
            Console.WriteLine("Ошибка десериализации.");
        }

        Cross500[] cr500New = jsoner.DeserializeFrom<Cross500[]>(path500js);
            if (cr500New != null)
            {
                Console.WriteLine($"Считаны данные из {path500js}");
                foreach (Cross500 cr5 in cr500New)
                {
                Console.WriteLine($"Name: {cr5._famile}, Group: {cr5._group}, Prep {cr5._famileP}, Rez {cr5._time}, Norm {cr5._isNorm} ");
                }
                toWork(cr500New);
            }
            else
            {
                Console.WriteLine("Ошибка десериализации.");
            }
            Cross500[] cr500NewP = biner.DeserializeFrom<Cross500[]>(path500bin);
            if (cr500NewP != null)
            {
                Console.WriteLine($"Считаны данные из {path500bin}");
                foreach (Cross500 cr5 in cr500NewP)
                {
                    Console.WriteLine($"Name: {cr5._famile}, Group: {cr5._group}, Prep {cr5._famileP}, Rez {cr5._time}, Norm {cr5._isNorm} ");
                }
                toWork(cr500NewP);
            }
            else
            {
                Console.WriteLine("Ошибка десериализации.");
            }

        Cross500[] cr500NewX = xmler.DeserializeFrom<Cross500[]>(path500xml);
        if (cr500NewX != null)
        {
            Console.WriteLine($"Считаны данные из {path500xml}");
            foreach (Cross500 cr5 in cr500NewX)
            {
                Console.WriteLine($"Name: {cr5._famile}, Group: {cr5._group}, Prep {cr5._famileP}, Rez {cr5._time}, Norm {cr5._isNorm} ");
            }
            toWork(cr500NewX);
        }
        else
        {
            Console.WriteLine("Ошибка десериализации.");
        }


    }
        static void toWork(Sportsmen[] sportsmens)
        {
            Console.WriteLine("Исходные данные");
            sportsmens[0].PrintTitle();
            foreach (Sportsmen sp in sportsmens)
            {
                sp.Print();
            }
            Sort(sportsmens);
            Console.WriteLine("После обработки");
            sportsmens[0].PrintTitle();
            int kol = 0;
            foreach (Sportsmen sp in sportsmens)
            {
                sp.Print();
                if (sp._isNorm) kol++;
            }
            Console.WriteLine("Выполнили норматив {0} чел.", kol);

        }
        static void Sort(Sportsmen[] cross)
        {
            int imin;
            for (int i = 0; i < cross.Length - 1; i++)
            {
                imin = i;

                for (int j = i + 1; j < cross.Length; j++)
                {
                    if (cross[j]._time < cross[imin]._time)
                    {
                        imin = j;
                    }
                }
                Sportsmen spTemp = cross[i];
                cross[i] = cross[imin];
                cross[imin] = spTemp;
            }
        }
    }

