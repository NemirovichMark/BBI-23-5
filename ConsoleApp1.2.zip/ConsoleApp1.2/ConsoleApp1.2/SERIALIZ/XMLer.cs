using System;
using System.IO;
using System.Xml.Serialization;


    class XmlSerializerHelper : SerializerHelper
    {
     public override void SerializeTo<T>(T obj, string filePath)
        {
        try
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));

            using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
            {
                serializer.Serialize(fileStream, obj);
            }

        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error writing XML file: {ex.Message}");
        }
    }

    public override T DeserializeFrom<T>(string filePath)
    {
        try
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));

            using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
            {
                return (T)serializer.Deserialize(fileStream);
            }
        }
          
        catch (Exception ex)
        {
            Console.WriteLine($"Error reading XML file: {ex.Message}");
        }
        return default (T);
    }
}
