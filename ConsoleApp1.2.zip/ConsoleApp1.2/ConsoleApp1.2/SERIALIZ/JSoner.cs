using System.IO;
using System.Text.Json;


    class JsonSerializerHelper : SerializerHelper
    {
        public override void SerializeTo<T>(T obj, string filePath)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate))
            {
                JsonSerializer.Serialize(fs, obj);
            }
            // string json = JsonConvert.SerializeObject(obj);
            // File.WriteAllText(filePath, json);
        }

        public override T DeserializeFrom<T>(string filePath)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate))
            {
                return JsonSerializer.Deserialize<T>(fs);
            }
            return default(T);

        }
    }
