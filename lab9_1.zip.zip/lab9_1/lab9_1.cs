﻿using lab9_1.Serializers;
using System;
using System.Xml.Linq;
using System.Security.Cryptography.X509Certificates;


[ProtoBuf.ProtoContract()]
[ProtoBuf.ProtoInclude(1, typeof(PersonOfYear))]
public abstract class NomineeOfYear
{
    [ProtoBuf.ProtoMember(1)]
    public static int TotalVotes;
    [ProtoBuf.ProtoMember(2)]
    public string _name;
    [ProtoBuf.ProtoMember(3)]
    public int _votes;
    [ProtoBuf.ProtoMember(4)]
    public string Name
    {
        get => _name;  
        set => _name = value ?? string.Empty;
    }
    [ProtoBuf.ProtoMember(5)]
    public int Votes
    {
        get => _votes;
        set => _votes = value;
    }
    public NomineeOfYear() { }
    public NomineeOfYear(string name, int votes)
    {
        _name = name;
        _votes = votes;
        TotalVotes += votes;
    }

    public abstract void Print();
}
[ProtoBuf.ProtoContract()]
public class PersonOfYear : NomineeOfYear
{
    public PersonOfYear(): base () { }
    public PersonOfYear(string name, int votes) : base(name, votes)
    {
    }

    public override void Print()
    {
        Console.WriteLine("Кандидат: {0}\tКол-во голосов: {1}\t", _name, _votes);
    }

    public static double GetPerVotes(int votes)
    {
        return (double)votes / TotalVotes * 100;
    }
}

//public class DiscoveryOfYear : NomineeOfYear
//{
//    public DiscoveryOfYear(string name, int votes) : base(name, votes)
//    {
//    }

//    public override void Print()
//    {
//        Console.WriteLine("Открытие: {0}\tКол-во голосов: {1}\t", _name, _votes);
//    }

//    public static double GetPerVotes(int votes)
//    {
//        return (double)votes / TotalVotes * 100;
//    }
//}

class Program
{
    static void Main()
    {
        PersonOfYear[] candidates = new PersonOfYear[]
        {
            new PersonOfYear("Бодя Федунь", 350),
            new PersonOfYear("Федя Кунгур", 200),
            new PersonOfYear("Армен Гогач", 500),
            new PersonOfYear("Сацик Насик", 400),
            new PersonOfYear("Немир Марков", 150),
            new PersonOfYear("Марк Немиров", 589),
            new PersonOfYear("Шорти Милан", 100)
        };
        Serial[] serializers = new Serial[3]
        {
            new JSONManager(),
            new BinManager(),
            new XMLManager()

        };
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        path = Path.Combine(path, "Task1");
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string[] files = new string[3]
        {
            "candidates.json",
            "candidates.bin",
            "candidates.xml",

        };
        for (int i = 0; i < files.Length; i++)
        {
            serializers[i].Write(candidates, Path.Combine(path, files[i]));

        }
        for (int i = 0; i < files.Length; i++)
        {
            candidates = serializers[i].Read<PersonOfYear[]>(Path.Combine(path, files[i]));
            foreach (PersonOfYear candidat in candidates)
            {
                candidat.Print();
            }
        }

        Console.WriteLine("Кандидаты на человека/открытие года:");
        foreach (var candidate in candidates)
        {
            candidate.Print();
        }
    }
    /*        FindTopCandidates(candidates);*/

    //    Console.WriteLine("Топ кандидатов на человека/открытие года:");
    //    for (int i = 0; i < 5 && i < candidates.Length; i++)
    //    {
    //        candidates[i].Print();
    //    }

    //    Console.WriteLine("\nДоли кандидатов в процентах от общего числа голосов:");
    //    for (int i = 0; i < 5 && i < candidates.Length; i++)
    //    {
    //        double percentage = PersonOfYear.GetPerVotes(candidates[i].Votes);
    //        Console.WriteLine($"{candidates[i].Name}: {percentage:f2}%");
    //    }
    //}

    static void FindTopCandidates(NomineeOfYear[] candidates)
    {
        int d = candidates.Length / 2;
        NomineeOfYear temp;
        while (d >= 1)
        {
            for (int i = d; i < candidates.Length; i++)
            {
                int j = i;
                temp = candidates[j];
                while (j >= d && candidates[j - d].Votes < candidates[j].Votes)
                {
                    candidates[j] = candidates[j - d];
                    candidates[j - d] = temp;
                    j = j - d;
                }
            }
            d = d / 2;
        }
    }
}
