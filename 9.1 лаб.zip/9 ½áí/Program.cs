﻿// 1 номер

/* 
Результаты соревнований по прыжкам в длину определяются по сумме двух
попыток. В протоколе для каждого участника указываются: фамилия, общество,
результаты первой и второй попыток. Вывести протокол в виде таблицы с
заголовком в порядке занятых мест.
1. Добавить поле «дисквалификация» и метод, который позволяет дисквалифицировать участника. 
В итоговую таблицу такие участники входить не должны. 
*/

using _9_лаб;
using System.Text.Json;
using System.Xml.Serialization;


public struct Sportsmen
{
    private string famile;
    private string society;
    private double _rez1;
    private double _rez2;
    private double _rez;
    private string _disqualification;

    public double rez1
    {
        get => _rez1;
        set => _rez1 = value;
    }

    public double rez2
    {
        get => _rez2;
        set => _rez2 = value;
    }

    public double rez
    {
        get => _rez;
        set => _rez = value;
    }

    public string disqualification
    {
        get => _disqualification; set => _disqualification = value;
    }

    public string Famile
    {
        get => famile;
        set => famile = value;
    }

    public string Society
    {
        get => society;
        set => society = value;
    }

    public Sportsmen(string famile1, string society1,
    double rezz1, double rezz2)
    {
        famile = famile1;
        society = society1;
        _rez1 = rezz1;
        _rez2 = rezz2;
        _rez = _rez1 + _rez2; _disqualification = string.Empty;
    }
    public void Disqualification(Sportsmen[] a)
    {
        a[2]._disqualification = "дисквалифицирован";
        a[5]._disqualification = "дисквалифицирован";
        a[6]._disqualification = "дисквалифицирован";
    }
    public void Print()
    {
        {
           if (_disqualification != "дисквалифицирован")
                Console.WriteLine("Фамилия {0}\t  Общество {1}\t 1 попытка {2:f2}  2 попытка {3:f2}  Результат  {4:f2}",
                    famile, society, _rez1, _rez2, _rez);
            
        }
    }
    public void Sort(Sportsmen[] a)
    {
        {
            int i = 0, j = 1;
            while (j < a.Length - 1)
            {
                if (i < 0 || a[i]._rez >= a[i + 1]._rez)
                {
                    i = j;
                    j++;
                }
                while (i >= 0 && a[i]._rez < a[i + 1]._rez)
                {
                    Sportsmen temp = a[i];
                    a[i] = a[i + 1];
                    a[i + 1] = temp;
                    i--;
                }
            }
        }
    }
}
class Program
{
    static void Main(string[] args)
    {
        Sportsmen[] sp = new Sportsmen[9];
        sp[0] = new Sportsmen("Иванов", "Юмористы", 1.57, 1.52);
        sp[1] = new Sportsmen("Петров", "Синяя Лагуна", 1.55, 1.80);
        sp[2] = new Sportsmen("Сидоров", "Солнце", 1.47, 1.50);
        sp[3] = new Sportsmen("Любимов", "Хмурая Туча", 1.46, 1.54);
        sp[4] = new Sportsmen("Макаров", "Фонарь", 1.64, 1.41);
        sp[5] = new Sportsmen("Зайцев", "Удача", 1.24, 1.47);
        sp[6] = new Sportsmen("Костин", "Символ", 1.43, 1.40);
        sp[7] = new Sportsmen("Мишкин", "Небеса", 1.52, 1.64);
        sp[8] = new Sportsmen("Рябинин", "Радость", 1.62, 1.65);

        Serial[] serializers = new Serial[2]
        {
            new JsonManager(),
            new XmlManager()
        };

        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        path = Path.Combine(path, "Sample1");
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string[] files = new string[2]
        {
            "task.json",
            "task.xml"
        };

        foreach (var sportsmen in sp)
        {
            sportsmen.Disqualification(sp);
        }
        foreach (var sportsmen in sp)
        {
            sportsmen.Sort(sp);
        }
        foreach (var sportsmen in sp)
        {
            sportsmen.Print();
        }

        for (int i = 0; i < files.Length; i++)
        {
            serializers[i].Write(sp, Path.Combine(path, files[i]));
        }

        for (int i = 0; i < files.Length; i++)
        {
            sp = serializers[i].Read<Sportsmen[]>(Path.Combine(path, files[i]));
            foreach (Sportsmen sp1 in sp)
            {
                sp1.Print();
            }
        }

    }
}

