﻿namespace Classes
{
    public partial class GameCatalog
    {
        public IEnumerable<BoardGame> Filter(Type gameType)
        {
            return games.Where(game => game.GetType() == gameType);
        }
    }
}