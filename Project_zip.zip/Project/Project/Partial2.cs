﻿namespace Classes
{
    public partial class GameCatalog
    {
        public void Sort()
        {
            games.Sort((g1, g2) => g1.Title.CompareTo(g2.Title));
        }
    }
}